````js
微信小程序reauest封装.md
// http(‘http://www.baidu.com’)(’/api/123’)

export default function(config) {

const { baseURL } = config; //传入baseurl

return function(vue) {

// console.log(vue);

vue.prototype.http = async function(params) {

// console.log(‘全局方法添加上了’);

const { url, method, data } = params;

const res=await uni.request({

url: baseURL + url,

method,

data,

});

// console.log(res);

return res[1].data //将数据第一项里面的data返回出去

};

};

}

在main.js中

import Vue from ‘vue’

import App from ‘./App’

import request from ‘@/utils/request’//引入自己封装的api

Vue.config.productionTip = false

App.mpType = ‘app’

const plugin=request({

baseURL:‘https://ugo.botue.com’

})//引用函数并且执行

Vue.use(plugin)//导入插件

const app = new Vue({

…App

})

app.$mount()

在组件中使用

const {message}=await this.http({url:’/api/public/v1/home/swiperdata’})

console.log(message);

}
````

