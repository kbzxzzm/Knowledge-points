import React from 'react';
import ReactDOM from 'react-dom';

// 导入全局初始化样式
import './index.css'
// 导入组件样式
import 'antd-mobile/dist/antd-mobile.css';
// 导入 字体图标
import './assets/fonts/iconfont.css'

import App from './App';



ReactDOM.render(<App />, document.getElementById('root'));

