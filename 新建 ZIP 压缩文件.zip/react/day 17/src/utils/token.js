// 后面token 经常操作 所以我打算封装一个 token.js 来对token 增删改查

// 获取token
export let getToken=()=>{
    return localStorage.getItem("my-token")
}
// 设置token
export let setToken=(val)=>{
  // val 传的参数是什么 就设置成什么
  return localStorage.setItem("my-token",val)
}

// 删除token
export let removeToken=()=>{

  return localStorage.removeItem("my-token")
}
// 判断是否登录 isAuth 返回 true 或者false 代表登录未登录
export let isAuth=()=>{

  // return !!localStorage.getItem("my-token")
  return !!getToken();//这两个是等价的
}