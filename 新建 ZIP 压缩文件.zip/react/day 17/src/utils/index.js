// 封装getCurrentCity() 获取当前定位城市
// export 导出多个 import {getCurrentCity} from '../../utils/index'
// export default 一般导一个 import 直接拿 from '../../utils/index'
import axios from 'axios'
export let getCurrentCity=()=>{
   //获取定位城市
   // 如果localstorage里面存了当前城市 我就直接获取 约定存的名字是 my-city
   // 如果没有 就重新定位城市 JSON.parse 转成对象或者数组
   let city=JSON.parse(localStorage.getItem("my-city"))
  //  console.log(city)
   if(!city){//没有城市 就应该去百度定位

       //没有 百度去定位
       var myCity = new window.BMap.LocalCity();
      //  这里是异步的 必须保证能拿到结果
      return new Promise((resolve,reject)=>{
          myCity.get( async (result)=>{
            var cityName = result.name;
            // alert("当前定位城市:"+cityName);
            // 还要获取 城市的id 只要发个请求就行
            let dingwei=await axios.get("http://localhost:8080/area/info?name="+cityName)
            console.log('定位城市信息',dingwei)
            // 定位拿到了 就存到 本地localstorage JSON.stringify(数组对象) 转成字符串
            localStorage.setItem("my-city",JSON.stringify(dingwei.data.body))
            // 返回 城市
            // return dingwei.data.body
            resolve(dingwei.data.body)
            // return 1123
          });
      })

      // return 456

   }else{
      // 直接用 获取的城市city
      // return new Promise((resolve,reject)=>{
      //     resolve(city)
      // })
      return Promise.resolve(city)
   }

}
