// 配置axios并导出
import axios from 'axios'

// console.log("地址",process.env.REACT_APP_URL)
import { BASE_URL } from './url'
import { getToken ,removeToken } from'./token'
// axios.defaults.baseURL='http://localhost:8080'
let API=axios.create({
  baseURL:BASE_URL
})

// 加上 axios的 请求拦截器 处理  需要token的请求头
// 添加请求拦截器 ：在所有axios请求 之前 一定会先 执行请求拦截器
API.interceptors.request.use(function (config) {
  // 在发送请求之前做些事  config 是所有的请求信息  config.url 是请求的地址
  // config.url--->  "/user/login"
  // console.log('请求拦截器执行了config',config)
  // axios请求 判断 如果需要token请求头的 就加上  不需要token 就不做
  // 哪些ajax需要token呢？ /user  开头的接口并且不是登录 注册 都需要token 其他的不需要
  //  "/user/login".startsWith('/user')  startsWith 以对应的开头 返回true 否则返回false
  if(
    config.url.startsWith('/user')
    &&config.url!=='/user/login'
    &&config.url!=='/user/registered'
  ){ //  /user  开头 并且不是登录 不是注册 需要token
    //  给请求加上  token
    //  config.headers.名字=token值
    config.headers.authorization=getToken()
  }

  // 最后必须 return返回
  return config;
});

// 响应拦截器 ：在所有的ajax请求  返回结果 之前 一定会执行 响应拦截器
// 添加响应拦截器 : 一般做判断 状态码 错误 提示信息 做操作 响应 200 400 500 302 404 等等...
API.interceptors.response.use(function (response) {
  //在返回结果之前   对响应数据做点什么
  // console.log("响应拦截器response",response)
  // 判断错误的 状态码  在这里写  所有的ajax 就不需要重复写这些代码了
  if(response.data.status===400){
    console.log('token有问题或者过期了失效了')
    // 删掉有问题的token
    removeToken()
  }else if(response.data.status===404){ // 找不到
    console.log('你的请求 找不到 地址是不是写错啦~~')
  }
  // ....  还可以 继续判断 其他的状态码
  // 一定要return 结果
  return response;
});
//API 就是配置了 url的 axios
export { API }