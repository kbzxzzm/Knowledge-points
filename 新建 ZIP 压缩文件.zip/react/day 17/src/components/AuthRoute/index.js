import React, { Component } from 'react'

// 如果登录了token 就正常显示页面组件 如果没有登录 就跳转到 
// 封装一下  因为很多页面需要判断 而且代码 都是Route这段代码
// 封装 需要 导入对应 用到的东西
import {Route,Redirect} from 'react-router-dom'
import { isAuth } from '../../utils/token'
// AuthRoute 一般 叫做 鉴权路由 权限路由 
export default class AuthRoute extends Component {
  render() {
    console.log('this.props',this.props)
    // 传来的 组件 首字母大写 因为是组件 要求
    let { Yemian ,path ,exact }=this.props
    return <Route 
              exact={exact} // 不写死 
              path={path} // 路由也不能写死 因为有很多都需要
              render={(newprops)=>{
                  // console.log('newprops',newprops);// 他就是 组件 的 路由相关信息 history match location
                  // 这种写法的好处是？ 我们可以在这里面做if判断
                  // 显示的组件 如果登录了token 就正常显示页面组件 如果没有登录 就跳转到 /login
                  if( isAuth() ){ //isAuth() true 登录 正常显示页面组件
                    //不要写死rent组件 我需要 你传什么页面组件  我就显示什么页面组件
                    // <Yemian history={newprops.history} location={newprops.location} ...  ></Yemian>
                    return <Yemian {...newprops}  ></Yemian>
                  }else{ //没有登录  重新跳转到 /login 页面

                      //  如果我访问 /rent 没有登录 就会跳转到  /login 去
                      // 那么  如果我在 /login 登录成功 那么 应该 调回刚刚访问的 /rent页面
                      // 在登录页面  需要 知道 你是哪个 页面 进来的登录 然后好跳转回去
                      // return <Redirect to="/login"></Redirect>
                      return <Redirect 
                      to={ {
                        pathname:'/login',
                        state:{ // 跳转login  并且带上了state 参数 里面有当前地址 因为后面登陆了可以再跳回来
                          from : newprops.location //  /rent 地址参数
                        }
                      } }
                      ></Redirect>
                  }
                  
            }} />
            // 总结：
            // 1 如果 /rent 没有登录就跳转到登录页面 并且带上当前地址在state
            // 2 在登录页面 登录成功 获取 state 直接原路 跳转回来
  }
}
