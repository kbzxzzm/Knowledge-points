import React, { Component } from 'react'
import { relative } from 'upath'

// Sticky 判断 滚动到距离 顶部 为0 让filter固定定位 fixed 设置样式 
export default class Sticky extends Component {
  // 1 创建 ref
  // 2 给标签或组件 写上 ref={this.创建的ref }
  // 3 通过 this.创建的ref.current  就可以拿到了
  pRef=React.createRef()
  cRef=React.createRef()
  // 滚动事件函数
  handleScroll=(e)=>{
    // 页面滚动出去的 距离
    // console.log('scrollTop',document.documentElement.scrollTop)
    // 元素距离顶部的 距离 --- 直接获取元素可以 也可以使用 ref
    // let pDiv=document.getElementById("placeholder")
    // 元素.getBoundingClientRect() 获取当前元素 距离 上下左右的 位置
    // console.log(pDiv.getBoundingClientRect())
    let pDiv=this.pRef.current
    let cDiv=this.cRef.current
    let ptop=pDiv.getBoundingClientRect().top
    // console.log('ptop',ptop);//距离 顶部 为0 让filter固定定位 fixed 设置样式 
    if(ptop<=0){//距离 顶部 为0 让filter固定定位 fixed 设置样式
        cDiv.style.position='fixed'
        cDiv.style.width="100%"
        cDiv.style.top=0
        cDiv.style.zIndex=9999
        // 让pDiv 占住 40px 高 免得 跳上去
        pDiv.style.height=this.props.height+'px'
    }else{// 还原到原来的样式
      cDiv.style.position='relative'
      // 还原成0 
      pDiv.style.height=0
    }
  }
  componentDidMount(){
      // 绑定窗口滚动事件
      window.addEventListener('scroll',this.handleScroll)

  }
  // 组件 卸载 销毁
  componentWillUnmount() {
    //  移除 scroll
    window.removeEventListener('scroll', this.handleScroll)
  }
  render() {
    return <div>
              {/* placeholder div 用来 获取和判断 距离 顶部的位置  */}
              <div ref={this.pRef} id="placeholder"></div>
              {/* content div 其实就操作Filter组件 要不要 固定定位 */}
              <div ref={this.cRef} id="content">
                {/* filter */}
                  {this.props.children}
              </div>
          </div>
  }
}

