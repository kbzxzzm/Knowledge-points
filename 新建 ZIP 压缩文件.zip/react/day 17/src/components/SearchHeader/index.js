import React, { Component } from 'react'
import {Flex} from 'antd-mobile'
//导入 withRouter
import {withRouter} from 'react-router-dom'
//使用prop-types 验证类型
// 1 下载导入 prop-types 2 组件.propTypes={属性:验证的规则}
import {PropTypes} from 'prop-types'
//封装 顶部搜索导航栏
// class组件 this.props 函数组件  传参数props
// 传参数props的时候 顺便直接解构了
function SearchHeader({cityname,history}){
  // console.log('props',props)
  // 解构
  // let {cityname,history} =props
   return <Flex className='searchBox'>
          <Flex className='searchLeft'>
              <div
              className='location'
              onClick={()=>{
                // 去选择切换城市
                history.push("/citylist")
              }}
              >
                {/* 修改城市名 */}
            <span>{cityname}</span>
              <i className="iconfont icon-arrow" />
              </div>
              <div
              className='searchForm'
              >
                  <i className="iconfont icon-seach" />
                  <span>请输入小区或地址</span>
              </div>
          </Flex>
          <i className="iconfont icon-map" 
          onClick={()=>{
              //跳转去 地图 map
              history.push("/map")
          }}  />
        </Flex>
}
// 2 组件.propTypes={
//   属性:验证的规则
// }
SearchHeader.propTypes={
  cityname:PropTypes.string
}
//默认值
SearchHeader.defaultProps={
  // 属性：默认值
  cityname:'安顺'
}
export default withRouter(SearchHeader)