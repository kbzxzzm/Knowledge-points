import React, { Component } from 'react'
import { NavBar ,Icon} from 'antd-mobile'
// 1 导入 withRouter 解决路由history问题
import { withRouter } from 'react-router-dom'
// 2 传入的值 类型验证
// 2.1 下载并导入 prop-types包
// 2.2 
// 组件.propTypes={
//     传来的属性:验证规则,
//     ...
// }
import PropTypes from 'prop-types'
class NavHeader extends Component {
  render() {
    return <NavBar
          className="navbar"
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => {
            //返回上一页
            // 如果组件 是通过 路由 /xx 这样直接访问显示的 那么history就正常
            // 如果你单独 封装了 再到过来用 history就有问题
            // console.log(this.props.history)
            this.props.history.go(-1)
          }}
        >{this.props.children}</NavBar>
  }
}
// 在导出直接 验证 规则
// 组件.propTypes={
//     传来的属性:PropTypes.类型,
//     ...
// }
NavHeader.propTypes={
   children:PropTypes.string
}
// 组件.defaultProps={属性名:默认值}
NavHeader.defaultProps={
    children:'默认导航'
}
// 1.2 把 withRouter(组件) 高价组件 包裹起来 就又可以了
export default withRouter(NavHeader)