import React, { Component } from 'react'

import { SearchBar } from 'antd-mobile'

import { getCurrentCity } from '../../../utils/index'

import styles from './index.module.css'

import {API} from '../../../utils/api'
export default class Search extends Component {
  // 当前城市id
  // cityId = getCurrentCity().value

  state = {
    // 搜索框的值
    searchTxt: '',
    tipsList: [] ,// 小区的列表数组
  }

  // 渲染搜索结果列表
  renderTips = () => {
    const { tipsList } = this.state

    return tipsList.map(item => (
      <li key={item.community} className={styles.tip}>
        {item.communityName}
      </li>
    ))
  }

//  做的事：
//   当文本框输入值 1 获取对应的关键字  1 发送ajax 获取1关键字相关的小区渲染到页面上
  getSearchTxt=async (value)=>{
    console.log('文本框的值',value)
    // 赋值
    this.setState({
      searchTxt:value
    })
    // 发送ajax 获取1 关键字相关的小区 渲染到页面上
    let dingwei=await getCurrentCity() ;//当前城市
    // http://localhost:8080/area/community?name=关键字&id=城市id
    let res=await API.get("/area/community",{
        params:{
          name:value,
          id:dingwei.value
        }
    })
    console.log('小区结果',res)
    this.setState({
      tipsList:res.data.body
    })
  }
  render() {
    const { history } = this.props
    const { searchTxt } = this.state

    return (
      <div className={styles.root}>
       
        {/* 搜索框 */}
        <SearchBar
          placeholder="请输入小区或地址"
          value={searchTxt}
          showCancelButton={true}
          onCancel={() => history.replace('/rent/add')}
          onChange={this.getSearchTxt}
        />

        {/* 搜索提示列表 */}
        <ul className={styles.tips}>{this.renderTips()}</ul>
      </div>
    )
  }
}
