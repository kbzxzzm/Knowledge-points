import React, { Component } from 'react'

export default class News extends Component {
  render() {
    return (
      <div className="news">
        我是资讯  news
      </div>
    )
  }
}
