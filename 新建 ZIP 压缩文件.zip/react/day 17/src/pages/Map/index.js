import React, { Component } from 'react'

import './map.scss'
// 导入 封装导航条组件
import NavHeader from '../../components/NavHeader'
// 导入局部的样式
import styles from  './map.module.css'
// console.log('styles',styles)
// 导入 封装的定位
// import {} from '../../utils/index'
import {getCurrentCity} from '../../utils'
// 导入 axios
import axios from 'axios'
// 导入 Toast
import {Toast} from 'antd-mobile'
// react 引入地图js后 BMap 必须加上window.BMap
let BMap=window.BMap
export default class Map extends Component {
  state={
      count:0,// 房子套数
      list:[], // 房子的数组
      isshow:false
  }
  // 必须保证页面有div了
  componentDidMount(){
     this.initMap()
  }
  // 封装显示地图
  async initMap(){
    // 地图初始化
    this.map = new BMap.Map("container");
    // 1 获取定位城市 把城市名 转换经纬度  显示对应的地图
    let dingwei=await getCurrentCity()
    // console.log("定位城市",dingwei)
    // 创建地址解析器实例     
    var myGeo = new BMap.Geocoder();      
    // 将地址解析结果显示在地图上，并调整地图视野    
    myGeo.getPoint(dingwei.label, (point)=>{      
        if (point) {      
          // point 当前城市的 经纬度
          this.map.centerAndZoom(point, 11);      
          // 设置地图控件
          this.map.addControl(new BMap.NavigationControl()); // 缩放控件  
          this.map.addControl(new BMap.ScaleControl());   // 比例尺
          this.map.addControl(new BMap.MapTypeControl());  //卫星三维
          
          // 封装 发送 请求 循环生成 覆盖物
          this.renderOverlays(dingwei.value,'cycle')

        }      
    }, 
    dingwei.label);

    // 绑定 地图移动时候  隐藏 房子列表
    this.map.addEventListener("movestart",()=>{
        this.setState({
          isshow:false
        })
    })
  
  }
  // 循环生成覆盖物
  renderOverlays=async (id,type)=>{
    // 显示loading
    Toast.loading('正在加载...',0)
    //1 先发送请求 获取 所有区的房子套数
    let res=await axios.get("http://localhost:8080/area/map?id="+id);//北京 区的房子
    console.log("房源数据",res)
    Toast.hide()
    //2 循环数组 生成很多覆盖物
    res.data.body.forEach(item=>{
        // let {coord}=item
        let point = new BMap.Point(item.coord.longitude, item.coord.latitude); 
        // 画一个圆形的覆盖物
        var opts = {
          position : point,    // 经纬度坐标 
          offset   : new BMap.Size(-35, -35)    //设置上下偏移x y
        }
        // var label = new BMap.Label("啊啊", opts)
        // label(内容,配置)就是覆盖物  map.addOverlay 添加覆盖物
        // label.setStyle 覆盖物外层盒子的样式
        var label = new BMap.Label("", opts);  // 创建文本标注对象
        // 你可以 1 直接写在上面 2 调用setContent写内容
        // 判断 如果是 区  县镇 显示圆形 如果是 小区 就显示 矩形
        if(type=='cycle'){
          label.setContent(
            ` <div class="${styles.bubble}">
                  <p class="${styles.name}">${item.label}</p>
                  <p>${item.count}套</p>
            </div>
            `
          )
        }else if(type=='rect') {
            label.setContent(`
                <div class="${styles.rect}">
                  <span class="${styles.housename}">${item.label}</span>
                  <span class="${styles.housenum}">${item.count}套</span>
                  <i class="${styles.arrow}"></i>
                </div>`
            )
        }
       
       
        label.setStyle({
          border:0,
          padding:0
        });
        // 给覆盖物绑定点击事件
        label.addEventListener("click",(e)=>{
            console.log('点击了覆盖物哦',item.value);//当前覆盖物的 id
            // 点击覆盖物 
            // 如果是 11 就去 13
            // 如果是 13  就去15
            // 如果是 15 就显示房子列表 
            // this.map.getZoom()  11 13 15 当前地图缩放
            let zoom=this.map.getZoom()
            if(zoom==11){
                 // 应该进入 县镇 13
                  this.map.centerAndZoom(point, 13);  
                  // 把上一次的 覆盖物先去掉 留下新的 报错：是百度地图bug  需要延时一下
                  setTimeout(()=>{
                    this.map.clearOverlays();
                  },10)
                  // 发送ajax获取数据 循环生成很多覆盖物
                  this.renderOverlays(item.value,'cycle')
            }else if(zoom==13){
                  // 应该进入 具体小区 15
                  this.map.centerAndZoom(point, 15);  
                  // 把上一次的 覆盖物先去掉 留下新的 报错：是百度地图bug  需要延时一下
                  setTimeout(()=>{
                    this.map.clearOverlays();
                  },10)
                  // 发送ajax获取数据 循环生成很多覆盖物
                  this.renderOverlays(item.value,'rect')
            }else if(zoom==15) {//具体小区
                console.log("不进去了，发送ajax获取房子列表 显示")
                // 把地图移动到中心点
                // 向上移动的距离=点击的Y坐标-中心点的y坐标
                // 向左移动的距离=点击的x坐标-中心点的x坐标
                console.log(e)
                let clickX=e.changedTouches[0].clientX 
                let clickY=e.changedTouches[0].clientY
                // 中心点y=(屏幕的高-房子列表高)/2  中心点x=屏幕宽/2
                let centerX=window.innerWidth/2
                let centerY=(window.innerHeight-330)/2
                // 移动的距离
                let distanceX=centerX-clickX
                let distanceY=centerY-clickY
                // 把地图移动 panBy(x距离,y距离)
                this.map.panBy(distanceX,distanceY)
                this.getHouselist(item.value)
            }
           

        })
        this.map.addOverlay(label); 
    })
     
  }
  // 获取房子列表 通过小区 id  去获取 房子
  getHouselist=async (id)=>{
     // 显示loading
     Toast.loading('正在加载...',0)
    // http://localhost:8080/houses?cityId=AREA%7C88cff55c-aaa4-e2e0
    let res=await axios.get("http://localhost:8080/houses?cityId="+id)
    console.log("房子列表数据",res)
    Toast.hide()
    // 赋值
    this.setState({
      count:res.data.body.count,
      list:res.data.body.list,
      isshow:true // 得到数据了 显示房子列表
    })
  }
  // 渲染 房子列表
  renderhouselist=()=>{
     return this.state.list.map(item=>{
              return <div key={item.houseCode} className={styles.house}>
                <div className={styles.imgWrap}>
                    <img className={styles.img} src={`http://localhost:8080${item.houseImg}`} alt="" />
                </div>
                <div className={styles.content}>
                    <h3 className={styles.title}>{item.title}</h3>
                    <div className={styles.desc}>{item.desc}</div>
                    <div>
                        {/* ['近地铁', '随时看房'] */}
                            {item.tags.map((val,index)=>{
                              // styles.tag1 tag2 tag3 
                              let tagclass='tag'+(index+1) // tag1 tag2 ...
                              return <span key={index} className={[styles.tag,styles[tagclass] ].join(' ')} >
                                    {val}
                                </span>
                            })}
                    </div>
                    <div className={styles.price}>
                    <span className={styles.priceNum}>{item.price}</span> 元/月
                    </div>
                </div>
            </div>
          })
  }
  
  render() {
    return (      
      <div className="map">
        {/* 地图找房 导航 */}
        {/* 标签之间内容是 children */}
        <NavHeader>
            地图找房
        </NavHeader>
      
        {/* 写一个div 用来放地图 */}
        <div id="container"></div>

        {/* 房子列表结构样式 [a,b].join(' ') a b */}
        <div
            className={[styles.houseList,  this.state.isshow ? styles.show : '' ].join(' ')}
        >
            <div className={styles.titleWrap}>
                <h1 className={styles.listTitle}>房屋列表</h1>
                <a className={styles.titleMore} href="/house/list">
                    更多房源
                </a>
            </div>
            {/* 外层列表 */}
            <div className={styles.houseItems}>
                {/* 每一项 */}
                {this.renderhouselist()}     
        
            </div>
        </div>

      </div>
    )
  }
}


















{/* <div className={styles.news}>
              我是map里面的news
      </div>
      <div className={styles.xxYy}>
          啊啊啊啊
      </div> */}