import React, { Component } from 'react'

import { NavBar, Icon,Toast } from 'antd-mobile';
// 导入 axios
import axios from 'axios'
import {getCurrentCity} from '../../utils/index'
// 导入样式
import './citylist.scss'
// react-virtualized使用 
// 1 下载 react-virtualized'
// 2 导入 import {List} from 'react-virtualized';
// 3 赋值List的 例子 把rowRenderer 放进组件 改成this.rowRenderer调用
import { List,AutoSizer } from 'react-virtualized';
// 导入封装的导航组件
import NavHeader from '../../components/NavHeader'
// 有房源的 数组
const HOST_CITY = ['北京', '上海', '广州', '深圳']

export default class Citylist extends Component {

  state={
    citylist:{},//列表
    cityindex:[],//单词数组
    indexactive:0//默认0索引的选中
  }
  // 创建一个ref
  listRef=React.createRef()

  componentDidMount(){
    // 发送请求获取所有城市数据
    this.getCityList()
  }
  /* 
  我们拿到的数据和我们要做的内容 不太匹配
    1 让后台改 2 自己改

  // 已有数据结构
      [
        {label:'北京',value:'',pinyin:'beijing',short:'bj'}，
        {label:'宝鸡',value:'',pinyin:'beijing',short:'bj'},
        {label: "安庆", value: "", pinyin: "anqing", short: "aq"}
        ...
      ]

  // 需要 把数据 转换成 我们想要的结构
  // 设计数据->添加分组标题
    var cityList = {
        //单词:[城市,..]
        'a':[{label:'安庆',short:'aq'},.....],
        'b':[{label:'北京',short:'bj'},{label:'宝鸡',short:'bj'},...],
        'c':[{label:'长沙',short:'cs'},....]
        ...
    }

  
  */
  // 获取所有城市数据的函数
  getCityList=async ()=>{
      //发送请求
      let res= await axios.get("http://localhost:8080/area/city?level=1")
      console.log("城市列表数据",res)
      //1 循环把原来的数据 转换成 我想要的
      let {citylist,cityindex}=this.formatcity(res.data.body)
      //2 发送请求获取热门城市
      let hotres=await axios.get("http://localhost:8080/area/hot")
      console.log("hotres",hotres)
      citylist['hot']=hotres.data.body
      cityindex.unshift("hot")
      //3 获取定位城市
      let dingwei=await getCurrentCity()
      console.log('dingwei',dingwei)
      citylist['#']=[dingwei]
      cityindex.unshift("#")
      console.log('修改的城市列表',citylist)
      console.log('单词列表数组',cityindex)
      // 赋值
      this.setState({
        citylist:citylist,
        cityindex:cityindex
      })
  }

  // 修改城市列表和得到单词列表数组
  formatcity=(list)=>{
      let citylist={
        // b:[城市]
      };//对象 
      list.forEach(item=>{
        // item 每一项城市 {label: "北京", value: "AREA|88cff55c-aaa4-e2e0", pinyin: "beijing", short: "bj"}
        // "bj".substr(0,1) ---》b  从0开始截取1个
        let word=item.short.substr(0,1);//b c ...
        if(citylist[word]){//有就追加  没有 undefinded 
          // citylist[word] citylist['b']  
          citylist[word].push(item)

        }else{//没有 就加一个数组 里面应该有第一个 否则就会跳过他
          citylist[word]=[item]
          //b:[北京]
        }
      })
      // console.log("修改后的城市列表",citylist);//对象数据正确 从a-z排好了
      // 得到右侧单词列表
      let cityindex=Object.keys(citylist).sort();// 把对象的键 拿出来组成新数组 返回 需要排序
      // console.log('单词列表cityindex',cityindex)
      // 返回 城市列表+单词列表
      return {
        citylist,
        cityindex
      }
  }
  // 每一项盒子的html 循环的
  rowRenderer=({
    key, // 唯一key
    index, // 数组的索引
    isScrolling, // 是否正在滚动 滚动true 
    isVisible, // 是否可见
    style, // 必须写style 他才能写上样式
  })=> {
    // console.log('rowRenderer执行了渲染',list[index])
    let word=this.state.cityindex[index];//# hot a b c...
    let citys=this.state.citylist[word];//单词对应的城市数组
    return (
      <div key={key} style={style} className="city">
            <div className="title">{this.formatword(word)}</div>
            {/* 城市-循环城市数组 显示几个城市 */}
            {/* 给 每个城市绑定点击事件 判断是否有房源 */}
            {citys.map((item)=>{
                return <div 
                key={item.value} 
                className="name"
                onClick={()=>{
                   //判断是否有房源
                  //  数组.indexOf(值) 找到返回索引找不到返回-1
                   if(HOST_CITY.indexOf(item.label)!==-1){//在数组 就是北上广深 有房源
                      // 把localstorage存的 当前城市 改成 点击的
                      localStorage.setItem('my-city',JSON.stringify(item))
                      // 找到返回首页
                      this.props.history.push("/home/index")
                   }else{//没有
                      // 提示 暂无房源
                      Toast.info('暂无房源哦 ~~~', 2);
                   }
                }}
                >{item.label}</div>
            })}
            
      </div>
    );
  }
  // 格式化 小写字母单词 写中文
  formatword=(word)=>{
      // 如果是 # 写 当前定位
      // 如果是 hot 写 热门城市
      // 如果是其他单词 就变大写
      switch (word) {
        case '#':
          return '当前定位'
        case 'hot':
          return '热门城市'
        default:
          return word.toUpperCase()

      }
  }

  // 每个盒子的高度
  getHeight=({index})=>{
      // console.log('index',index)
      let word=this.state.cityindex[index];// a b c
      let citys=this.state.citylist[word];//城市数组
      // 计算每一个的高度 返回 可以动态的设置不同的高度
      // 高度=单词的高度+城市数量*单个城市的高度
      // 高度=36+城市数量*50
      return 36+citys.length*50
  }

  // 循环生成 单词列表li
  renderIndex=()=>{
    return this.state.cityindex.map((item,index)=>{
      return <li 
          key={index} 
          className={index===this.state.indexactive?"index-active":''}
          onClick={()=>{
             //点击 让左侧List滚动到对应位置
            //  只需要 通过ref 获取到List组件 让他调用 scrollToRow
            // this.listRef.current 就是 list
            this.listRef.current.scrollToRow(index)
          }}
          >
            {item==='hot'?'热':item.toUpperCase()}
          </li>
    })
  }

  // ({ overscanStartIndex: number, overscanStopIndex: number, startIndex: number, stopIndex: number }): void
  // void 不需要返回值
  // 滚动顶部 拿到顶部的索引 去修改 indexactive  对应的 索引字母 就高亮了
  onRowsRendered=({overscanStartIndex,overscanStopIndex,startIndex,stopIndex})=>{
    //  0 14 0 4 startIndex 滚动到顶部的 那个索引
    // console.log('onRowsRendered函数',startIndex)
    // 哪个索引滚动到顶部 就把 选中的indexactive 改成 这个索引 就对应高亮
    // 如果值变化了 才 去修改 效率高一点
    if(startIndex!==this.state.indexactive){
      this.setState({
        indexactive:startIndex
      })
    }
  }

  render() {
    return (
      <div className="citylist">
        {/* 导航 */}
        {/* <NavBar
          className="navbar"
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => {
            //返回上一页
            // console.log(this.props)
            this.props.history.go(-1)
          }}
        >城市选择</NavBar> */}
        {/* 内容 列表可视区域渲染 */}
        <NavHeader>城市列表</NavHeader>
        <AutoSizer>
            {({height, width}) => (
              // 把ref放在你要获取的上面
              <List
                ref={this.listRef}
                scrollToAlignment='start'
                width={width} // 可视区宽
                height={height} //可视区高
                rowCount={this.state.cityindex.length} // 总条数
                rowHeight={this.getHeight}//数字或者函数 每一项盒子的高度
                rowRenderer={this.rowRenderer} // 每个盒子的html样式
                onRowsRendered={this.onRowsRendered} // 滚动列表触发
              />
              
            )}
          </AutoSizer>
          {/* 右侧单词列表 */}
          <ul className="city-index">
            {/* 循环单词列表数组 生成很li */}
            {this.renderIndex()}
          </ul>
        
      </div>
    )
  }
}
