import React, { Component } from 'react'

// 导入轮播图
import { Carousel , Flex ,Grid  } from 'antd-mobile';
// 导入axios
import axios from 'axios'
// 导入封装的
import { API } from '../../utils/api'
// 导入scss
import './index.scss'
// 导入本地图片
import nav1 from '../../assets/images/nav-1.png'
import nav2 from '../../assets/images/nav-2.png'
import nav3 from '../../assets/images/nav-3.png'
import nav4 from '../../assets/images/nav-4.png'
// 导入封装好的 获取城市
import { getCurrentCity } from '../../utils/index'
// 整租合租数据
const navs = [{
  id: 0,
  img: nav1,
  title: '整租',
  path: '/home/houselist'
}, {
  id: 1,
  img: nav2,
  title: '合租',
  path: '/home/houselist'
}, {
  id: 2,
  img: nav3,
  title: '地图找房',
  path: '/map'
}, {
  id: 3,
  img: nav4,
  title: '去出租',
  path: '/rent/add'
}]

export default class Index extends Component {
  state = {
    swiperData: [],
    imgHeight: 176,
    isplay:false, //不轮播
    groups:[],//租房小组
    news:[], //新闻
    cityname:''
  }
  // 发送请求 获取轮播图数据
  async componentDidMount() {
    // 发送ajax 获取轮播图数据
    this.getSwiperdata()
    // 发送ajax 获取租房小组数据
    this.getGroups()
    //  发送ajax  获取 新闻资讯数据
    this.getNews()
    // 根据ip使用百度地图定位城市
    // var myCity = new window.BMap.LocalCity();
    // myCity.get((result)=>{
    //   var cityName = result.name;
    //   // alert("当前定位城市:"+cityName);
    //   // 设置城市
    //   this.setState({
    //     cityname:cityName
    //   })
    // }); 
    let dingwei=await getCurrentCity()
    console.log(dingwei)
    this.setState({
      cityname:dingwei.label
    })

  }

  // 获取轮播图数据
  async getSwiperdata(){
    // let res= await axios.get("http://localhost:8080/home/swiper")
    let res= await API.get("/home/swiper")
    console.log("轮播图数据",res)
    // 赋值
    this.setState({
      swiperData:res.data.body
    },()=>{
      // 数据一定成功了执行这个函数
      this.setState({
        isplay:true //改成true
      })
    })


  }
  // 获取租房小组数据
  async getGroups(){
    // 发送请求
    let res=await axios.get("http://localhost:8080/home/groups?area=AREA%7C88cff55c-aaa4-e2e0")
    console.log("租房小组数据",res)
    if(res.data.status===200){
      //  赋值
      this.setState({
        groups:res.data.body
      })
    }
  }
  // 获取新闻资讯数据
  async getNews(){
    // 发送请求
    let res=await axios.get("http://localhost:8080/home/news?area=AREA%7C88cff55c-aaa4-e2e0")
    console.log("新闻资讯数据",res)
    // 赋值
    if(res.data.status===200){
      this.setState({
        news:res.data.body
      })
    }
  }

  // 渲染轮播图图片
  renderSwiper(){
    return this.state.swiperData.map(item => (
            <a
              key={item.id}
              href="http://www.alipay.com"
              style={{ display: 'inline-block', width: '100%', height: this.state.imgHeight }}
            >
              <img
                src={'http://localhost:8080'+item.imgSrc}
                alt=""
                style={{ width: '100%', verticalAlign: 'top' }}
                onLoad={() => {
                  // 窗口改变的时候 图片适应宽高
                  window.dispatchEvent(new Event('resize'));
                  this.setState({ imgHeight: 'auto' });
                }}
              />
            </a>
        )
    )
  }
  // 循环渲染 整租合租
  renderNavs(){
      return navs.map(item=>{
          return <Flex.Item 
                key={item.id}
                onClick={()=>{
                    // 跳转
                    this.props.history.push(item.path)
                }}>
                <img src={item.img} alt=""/>
                <p>{item.title}</p>
              </Flex.Item>
        })
  }

  // 循环渲染 新闻资讯li
  renderNews(){
    return this.state.news.map((item)=>{
        return <li key={item.id}>
          <img src={"http://localhost:8080"+item.imgSrc} alt=""/>
          <div className="content-right">
            {/* 右边 */}
            <h4>{item.title}</h4>
            <p>
              <span>{item.from}</span>
              <span>{item.date}</span>
            </p>
          </div>
      </li>
    })
  }

  render() {
    return (
      <div className="index">
        {/* 顶部搜索栏 */}
          <Flex className='searchBox'>
              <Flex className='searchLeft'>
                  <div
                  className='location'
                  onClick={()=>{
                    // 去选择切换城市
                    this.props.history.push("/citylist")
                  }}
                  >
                    {/* 修改城市名 */}
                  <span>{this.state.cityname}</span>
                  <i className="iconfont icon-arrow" />
                  </div>
                  <div
                  className='searchForm'
                  >
                      <i className="iconfont icon-seach" />
                      <span>请输入小区或地址</span>
                  </div>
              </Flex>
              <i className="iconfont icon-map" 
              onClick={()=>{
                  //跳转去 地图 map
                  this.props.history.push("/map")
              }}  />
          </Flex>
          {/* 轮播图 */}
            <Carousel
              autoplay={this.state.isplay} // true自动轮播 有问题 一开始打开没数据 没生效 有数据再设置能生效
              infinite
            >
              {this.renderSwiper()}
            </Carousel>
          {/* 整租合租 
            img src :1 http开头网络图片 可以生效 2 本地图片 没生效 需要先import 
            [
              {id:1,img:图片,name:整租,path:跳转地址}...
            ]
          */}
          <Flex className="nav">
            {this.renderNavs()}
          </Flex>
          {/* 租房小组 */}
          <div className="groups">
              <div className="groups-title">
                    <h3>租房小组</h3>
                    <span>更多</span>
              </div>
              {/* 四个盒子 先去拿到数据 Grid 宫格 每行占几个盒子
                       data 数组数据
                       columnNum 默认一行四个 写2
                       renderItem el数组每一项 index 索引 是一个函数 每个格子的html样式
                      square true正方形 false矩形
                      hasLine true有线边框 false不要
                      activeStyle点击 true 有灰色样式 false没有
               */}
              <Grid 
                data={this.state.groups} 
                columnNum={2} 
                square={false}
                hasLine={false}
                renderItem={(item,index)=>{
                    // 每个格子的内容 
                    return <Flex className="grid-item" justify="between">
                            <div className="desc">
                              <h3>{item.title}</h3>
                              <p>{item.desc}</p>
                            </div>
                            <img src={`http://localhost:8080${item.imgSrc}`} alt="" />
                          </Flex>
                }}
                activeStyle={true} 
              />

          </div>

          {/*  最新资讯  */}
          <div className="news">
                <h3>最新资讯</h3>
                <div className="news-content">
                    <ul>
                      {/* 循环生成 li 新闻 */}
                      {this.renderNews()}
                      
                    </ul>
                </div>
          </div>
      </div>
    )
  }
}
