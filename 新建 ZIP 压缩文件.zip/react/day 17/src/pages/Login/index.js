import React, { Component } from 'react'
import { Flex, WingBlank, WhiteSpace,Toast } from 'antd-mobile'

import { Link } from 'react-router-dom'

import NavHeader from '../../components/NavHeader'

import styles from './index.module.css'
import { API } from '../../utils/api'


import { withFormik,Form,Field,ErrorMessage } from 'formik';

// 下载并导入 yup
import * as Yup from 'yup'

// console.dir(NavHeader)
// 验证规则：
// const REG_UNAME = /^[a-zA-Z_\d]{5,8}$/
// const REG_PWD = /^[a-zA-Z_\d]{5,12}$/
// 受控表单  被state数据绑定控制的表单
class Login extends Component {
  render() {
    // console.log('登录的props',this.props)
    // 只要你用withformik包裹了 组件再props身上 就会多很多他增加的功能代码
    return (
      <div className={styles.root}>
        {/* 顶部导航 */}
        <NavHeader className={styles.navHeader}>账号登录</NavHeader>
        <WhiteSpace size="xl" />

        {/* 登录表单 */}
        <WingBlank>
          <Form>
            <div className={styles.formItem}>
              <Field type='text' className={styles.input} name="username" placeholder="请输入账号"   />
            </div>
            {/* 长度为5到8位，只能出现数字、字母、下划线 */}
            {/* 有错误才显示 */}
            <ErrorMessage  className={styles.error} name='username' component='div'   />
            <div className={styles.formItem}>
              <Field type='password' className={styles.input} name="password" placeholder="请输入密码"   />
            </div>
            {/* 长度为5到12位，只能出现数字、字母、下划线 */}
            <ErrorMessage  className={styles.error} name='password' component='div'   />
            <div className={styles.formSubmit}>
              <button className={styles.submit} type="submit">
                登 录
              </button>
              {/* 如果button不是  type="submit" 那么  是普通按钮 触发 onclick点击事件*/}
              {/* 如果button  type="submit" 叫提交按钮会提交表单刷新 
                                触发 form 标签的 onsubmit事件 */}
            </div>
          </Form>
          <Flex className={styles.backHome}>
            <Flex.Item>
              <Link to="/registe">还没有账号，去注册~</Link>
            </Flex.Item>
          </Flex>
        </WingBlank>
      </div>
    )
  }
}
// 我们传入组件  返回一个 多了 很多代码功能的 新组件  
// withFormik 你需要传一个组件进去 他返回 带了对应验证代码的  一个新组件
//   高级组件形式  
// const MyEnhancedForm = withFormik({})(Login);
// export default Login
// mapProps... 把值 赋值到 props上
export default withFormik({
  // mapPropsToValues 使用withFormik 表单数据就不要写state了 就写在这mapPropsToValues
  mapPropsToValues: () =>  ({ username:'',password:'' }),// 替代state表单数据 this.props.values.username即可
  // 第一种验证表单 方式 1 validate 配置验证返回errors 2 在props里面拿出errors 3 判断有错就显示错误信息div
  // validate: (values) => {
  // },
  // 第二种验证表单方式validationSchema:Yup验证
  // Yup 干嘛的？其实就这个专门验证的包 已经帮我们写好了很多正则表达式 判断了 如果你需要其他的还可以自己matches加上
  validationSchema:Yup.object().shape({
      // 表单值:验证规则       .matches(正则,错误的提示信息)
      username:Yup.string().required('用户名必须填写').matches(/^\w{5,8}$/,'用户名必须5-8位'),
      password:Yup.string().required('密码必须填写').matches(/^\w{5,12}$/,'密码必须5-12位')
  }),
  //submit 提交表单执行的函数 替代我们写的
  handleSubmit:async (values, { props }) => {
    // 这里 他会自己帮我们阻止跳转
    // 获取用户名和密码 发送ajax去登录
    console.log('用户名密码',values)
    //2 去 发送 ajax 登录  // http://localhost:8080/user/login 
    let res=await API.post("/user/login",{
        username:values.username,
        password:values.password
    })
    console.log('登录结果',res)// 错误是400 成功是200 还返回了token
    if(res.data.status===200){
        Toast.success('登录成功', 1)
      //  登录成功 会有  token  后期如果没有token 就代码 没有登录 
        console.log('token',res.data.body.token)
      //  把token存起来 后面好用 
      localStorage.setItem("my-token",res.data.body.token)
      // 应该判断 如果是从 某个地址过来的 登录成功 应该 跳回去
      // 获取跳回去的地址 然后才可以跳回去
      console.log('跳来的地址',props)
      if(props.location.state){
        // 如果有state 就跳转回去
        props.history.push(props.location.state.from.pathname)
      }else{
        // 没有state 我们正常就返回上一页
        props.history.go(-1)
      }

    }else{
      Toast.fail('失败啦~！', 1)
    }
  }
})(Login);

// import Login from '...'
// 总结 
//1  下载formik并导入withFormik
//2  withFormik({})(要验证的组件) 配置 mapPropsToValues数据   handleSubmit提交 validationSchema验证
//3  在组件里面 使用 props里面带的  values配置表单  
//                     handleChange配置onChange  handleSubmit配置onSubmit事件 errors 错误信息对象
//    let { values,handleChange,handleSubmit ,errors}=this.props
//4 在 表单里面  判断errors 有错误就显示 对应的错误div

//总结 简化表单
// 1 导入 import { withFormik,Form,Field,ErrorMessage } from 'formik';
// Form 替换form标签 可以不写submit了
// Field 替换input 可以不写value 和onchange
// ErrorMessage 替换错误div  可以不判断errors了
// 2 可以删掉前面用的那些props了
// 为什么可以不写？因为这些组件 他已经封装了 所以可以不写


