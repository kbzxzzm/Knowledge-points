import React, { Component } from 'react'

import { Link } from 'react-router-dom'
import { Grid, Button ,Modal } from 'antd-mobile'

import { BASE_URL } from '../../utils/url'

import styles from './index.module.css'

import { isAuth ,getToken ,removeToken} from '../../utils/token'

import { API } from '../../utils/api'

// 菜单数据
const menus = [
  { id: 1, name: '我的收藏', iconfont: 'icon-coll', to: '/favorate' },
  { id: 2, name: '我的出租', iconfont: 'icon-ind', to: '/rent' },
  { id: 3, name: '看房记录', iconfont: 'icon-record' },
  {
    id: 4,
    name: '成为房主',
    iconfont: 'icon-identity'
  },
  { id: 5, name: '个人资料', iconfont: 'icon-myinfo' },
  { id: 6, name: '联系我们', iconfont: 'icon-cust' }
]

// 默认头像
const DEFAULT_AVATAR = BASE_URL + '/img/profile/avatar.png'

// const alert = Modal.alert; 如果不写这句话 那么后面 就 直接 Modal.alert

export default class Profile extends Component {
  // 判断 登录 就显示 登录的 样式结构  没有登录 就显示 未登录的样式结构
  // 什么情况叫 登录了？有token代表登录了 islogin 是true
  // localStorage.getItem("my-token") 获取token 有就是字符串token 没有是null
  //  !!localStorage.getItem("my-token") --可以转成true 或者false
  // 后面token 经常操作 所以我打算封装一个 token.js 来对token 增删改查
  state={
    // islogin:!!localStorage.getItem("my-token"),// true代表登录 false 代表未登录 
    islogin:isAuth(),
    userinfo:{
      avatar:'',// 头像
      nickname:''// 昵称
    }
  }

  // 页面一进来  就判断是否登录 如果登录了 就发ajax 去获取头像和昵称显示到页面
    //                        如果没有登录 就默认显示  默认头像和 游客
  componentDidMount(){
    //ajax 去获取头像和昵称显示到页面
    this.getuserinfo() 
  }
  //ajax 去获取头像和昵称显示到页面
  getuserinfo=async ()=>{
    //  没有登录 就没必要发送
    if(!this.state.islogin){
       return;
    }
    // 登录了 就发送请求 去获取用户名和头像
    // http://localhost:8080/user 需要带上 token 请求头
    let token=getToken();//token   localStorage.getItem("my-token")
    let res=await API.get("/user",{
      //  headers:{
      //     //键:值  
      //     authorization:token
      //  }
    })

    console.log('用户信息',res);// 200 成功 400 token有问题
    if(res.data.status===200){
      // 赋值
      this.setState({
         userinfo:{
            avatar:res.data.body.avatar,// 头像
            nickname:res.data.body.nickname// 昵称
         }
      })
    }else{
      console.log('token有问题')
    }

  }
  
  //点击退出按钮 弹出对话框，提示是否确定退出 如果退出就去退出 取消就不做事
  // Modal 的意思 模态框 对话框 弹出框 一般前端都叫这个名字
  logout=()=>{
    // 弹出对话框，提示是否确定退出 如果退出就去退出 取消就不做事
    Modal.alert('退出', '你确定要退出吗?', [
      { 
        text: '取消', 
        onPress: () => {//点击取消
            console.log('取消')
        } 
      },
      { 
        text: '退出', 
        onPress: async () => {// 点击确定 
          console.log('确定退出')
          // 就去  实现 真正的退出 就行了 
          // 注意 axios.get(地址,{请求头})   axios.post(地址,参数,{请求头})
          // 1 调用退出接口  实现后台退出
          let res=await API.post("/user/logout",null,{
            // headers:{
            //   authorization:getToken()
            // }
          })
          console.log('退出结果',res)
          if(res.data.status===200){
            // 2 删除我们存的token
            removeToken()
            // 3 页面显示 未登录 的 样式 -- 数据全部重新初始化
            this.setState({
                islogin:false,
                userinfo:{
                  avatar:'',
                  nickname:''
                }
            })
          }
          

        } 
      },
    ])
  }
  render() {
    const { history } = this.props
    let { avatar , nickname }=this.state.userinfo
    return (
      <div className={styles.root}>
        {/* 个人信息 */}
        <div className={styles.title}>
          <img
            className={styles.bg}
            src={BASE_URL + '/img/profile/bg.png'}
            alt="背景图"
          />
          <div className={styles.info}>
            <div className={styles.myIcon}>
              {/* 头像 */}
              <img className={styles.avatar} 
                  src={ avatar ? BASE_URL+ avatar : DEFAULT_AVATAR } 
                   alt="icon" />
            </div>
            <div className={styles.user}>
              <div className={styles.name}>
                {/* 昵称 */}
                { nickname ? nickname : '游客' }
              </div>
              {/* // 判断 登录true 就显示 登录的 样式结构  没有登录 就显示 未登录的样式结构 */}
              {/* 登录后展示： */}
              {
                this.state.islogin 
                ? 
                // 登录的结构
                <>
                  <div className={styles.auth}>
                    <span onClick={this.logout}>退出</span>
                  </div>
                  <div className={styles.edit}>
                    编辑个人资料
                    <span className={styles.arrow}>
                      <i className="iconfont icon-arrow" />
                    </span>
                  </div>
                </>
                : 
                // 未登录结构
                <div className={styles.edit}>
                  <Button
                    type="primary"
                    size="small"
                    inline
                    onClick={() => history.push('/login')}
                  >
                    去登录
                  </Button>
              </div>

              }
    
              
            </div>
          </div>
        </div>

        {/* 九宫格菜单 */}
        <Grid
          data={menus}
          columnNum={3}
          hasLine={false}
          renderItem={item =>
            item.to ? (
              <Link to={item.to}>
                <div className={styles.menuItem}>
                  <i className={`iconfont ${item.iconfont}`} />
                  <span>{item.name}</span>
                </div>
              </Link>
            ) : (
              <div className={styles.menuItem}>
                <i className={`iconfont ${item.iconfont}`} />
                <span>{item.name}</span>
              </div>
            )
          }
        />

        {/* 加入我们 */}
        <div className={styles.ad}>
          <img src={BASE_URL + '/img/profile/join.png'} alt="" />
        </div>
      </div>
    )
  }
}
