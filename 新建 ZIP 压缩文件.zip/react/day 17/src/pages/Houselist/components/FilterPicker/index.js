import React, { Component } from 'react'

import { PickerView } from 'antd-mobile'

import FilterFooter from '../../../../components/FilterFooter'
//写死的数据
const province = [
  {
    label: '北京',
    value: '01',
    children: [
      {
        label: '东城区',
        value: '01-1'
      },
      {
        label: '西城区',
        value: '01-2'
      },
      {
        label: '崇文区',
        value: '01-3'
      },
      {
        label: '宣武区',
        value: '01-4'
      }
    ]
  },
  {
    label: '浙江',
    value: '02',
    children: [
      {
        label: '杭州',
        value: '02-1',
        children: [
          {
            label: '西湖区',
            value: '02-1-1'
          },
          {
            label: '上城区',
            value: '02-1-2'
          },
          {
            label: '江干区',
            value: '02-1-3'
          },
          {
            label: '下城区',
            value: '02-1-4'
          }
        ]
      },
      {
        label: '宁波',
        value: '02-2',
        children: [
          {
            label: 'xx区',
            value: '02-2-1'
          },
          {
            label: 'yy区',
            value: '02-2-2'
          }
        ]
      },
      {
        label: '温州',
        value: '02-3'
      },
      {
        label: '嘉兴',
        value: '02-4'
      },
      {
        label: '湖州',
        value: '02-5'
      },
      {
        label: '绍兴',
        value: '02-6'
      }
    ]
  }
]
// 点击区域 方式 租金 使用对应的不同数据
// 如果关掉 再打开 Picker 是重新执行 重新渲染
// 如果打开 不关掉 切换 Picker就没有重新渲染 
export default class FilterPicker extends Component {
  state={
    value:this.props.defaultValues// 默认选中的值
  }
  // 复杂写法 记得接受props
  // constructor(props){
  //   super(props)
  //   this.state={
  //     value:this.props.defaultValues// 默认选中的值
  //   }
  //   console.log('construct执行了')
  // }
  render() {
    // 接受传来的数据 
    // this.props.onCancel
    return (
      <> 
        {/* antd-mobile 选择器组件： data 显示的数据 数组 value默认选中值 cols列数 onChange  选择的时候触发*/}
        <PickerView 
        data={this.props.data} 
        value={this.state.value} // 如果选择了 进来就要默认显示刚刚选中的
        cols={this.props.cols}
        onChange={(val)=>{
          // console.log('选择后的值',val)
          // 选择了 就把默认的null 改成选择的 下次进来显示默认选过的
          this.setState({
            value:val
          })
        }}
         />

        {/* 底部按钮 */}
        {/* 确定 不仅隐藏 还要把选择的值 只要去改掉 原来的默认值 */}
        <FilterFooter
         onCancel={this.props.onCancel}
        //  onSave={this.props.onSave} //没法写值
        onSave={()=>{
          // 传选择的值 给 filter onsave
          //  this.props.onSave('area','朝阳公园')
          this.props.onSave(this.props.type,this.state.value)
        }}
         />
      </>
    )
  }
}
