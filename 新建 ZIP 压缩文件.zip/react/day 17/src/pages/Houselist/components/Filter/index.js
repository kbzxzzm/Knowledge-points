import React, { Component } from 'react'

import FilterTitle from '../FilterTitle'
import FilterPicker from '../FilterPicker'
import FilterMore from '../FilterMore'

import styles from './index.module.css'
//导入api
import { API } from '../../../../utils/api'
import {getCurrentCity} from  '../../../../utils/index'
const titleSelectedStatus = {
  area: false,//区域
  mode: false,//方式
  price: false,// 租金
  more: false //筛选more
}
// 默认选中的值
const selectedValues = {
  area: ["area", null],
  mode: ["null"],
  price: ["null"],
  more: []
};
export default class Filter extends Component {
  state={
    titleStatus:titleSelectedStatus,// 是否高亮
    openType:'',//默认不显示picker 如果点击area mode price 才显示
    filterdata:{}, //筛选条件数据
    // selectedValues:selectedValues
    selectedValues
  }
  componentDidMount(){
    // 发送请求获取 area mode  price more的数据
    this.getFilterData()
  }
  // 发送请求获取 筛选 数据函数
  getFilterData=async ()=>{
      let dingwei=await getCurrentCity();//dingwei
      let res=await API.get("http://localhost:8080/houses/condition?id="+dingwei.value)
      console.log("筛选数据",res)
      this.setState({
        filterdata:res.data.body
      })
  }
  //父亲 标题点击的函数
  onTitleClick=(type)=>{
    console.log("父亲Filter的函数",type)
    // let newTitleStatus={...titleSelectedStatus}
    // newTitleStatus[type]=true
    // 1 对象后面同名覆盖前面 2 [属性] 表示变量
    // 高亮的条件 1 点击的立刻高亮 2 其他的有值的 也要高亮
    let newStatus={...this.state.titleStatus}// 高亮
    let newValues={...this.state.selectedValues}// 四个值
    console.log('点击看见选的值',newValues)
    for(let key in newValues){
      //  console.log(key);// area mode price more 单词
       if(key===type){//1 点击的那个 立刻高亮
         newStatus[key]=true;//高亮
         continue;// 结束这次循环 进行下一次
       }
      //其他的需要判断 有值的 也要高亮 selectedVal值
      // - 如果type为area，此时，selectedVal.length !== 2 || (selectedVal.length===2&&selectedVal[0] !== 'area')，就表示已经有选中值
      // - 如果 type 为 mode，此时，selectedVal[0] !== 'null'，就表示已经有选中值
      // - 如果 type 为 price，此时，selectedVal[0] !== 'null'，就表示有选中值
      let selectedVal=newValues[key];//每一个的 selectedVal值
      // 如果是area 并且 有值 area就选中
      if(key==='area'&&(selectedVal.length !== 2 || (selectedVal.length===2&&selectedVal[0] !== 'area')) ){
        newStatus[key]=true 
      }else if(key==='mode'&&selectedVal[0] !== 'null'){// 方式mode 并且有值
        newStatus[key]=true 
      }else if(key==='price'&&selectedVal[0] !== 'null'){// 租金 并且有值
        newStatus[key]=true 
      }else if(key==='more'&&selectedVal.length!==0){//筛选户型 并且有值
        newStatus[key]=true
      }else{
          newStatus[key]=false
      }


    }
    // console.log('newValues',newValues,newStatus)
    this.setState({
      titleStatus:newStatus,
      openType:type
    })
  }
  // 取消的函数 隐藏组件
  onCancel=()=>{
    // 顺便 判断 当前标题 是否高亮
    let newStatus={...this.state.titleStatus}
    let type=this.state.openType // 当前打开的area mode  price more
    let selectedVal=this.state.selectedValues[type];// selectedVal值

    // 如果是area 并且 有值 area就选中
    if(type==='area'&&(selectedVal.length !== 2 || (selectedVal.length===2&&selectedVal[0] !== 'area')) ){
      newStatus[type]=true 
    }else if(type==='mode'&&selectedVal[0] !== 'null'){// 方式mode 并且有值
      newStatus[type]=true 
    }else if(type==='price'&&selectedVal[0] !== 'null'){// 租金 并且有值
      newStatus[type]=true 
    }else if(type==='more'&&selectedVal.length!==0){//筛选户型 并且有值
      newStatus[type]=true
    }else{
        newStatus[type]=false
    }
    //隐藏 只需要 把openType值重新变成 ''
    this.setState({
      openType:'',
      titleStatus:newStatus
    })
  }

  // 确定的函数 1 隐藏组件 2 修改默认值 为 确定时候选择的
  onSave=(type,val)=>{
    // 顺便 判断一下 当前的标题 是否 高亮
    // 有没有值？ 不管怎么样 有值就应该高亮  没有值就不高亮 
    //其他的需要判断 有值的 也要高亮 selectedVal值
    // - 如果type为area，此时，selectedVal.length !== 2 || (selectedVal.length===2&&selectedVal[0] !== 'area')，就表示已经有选中值
    // - 如果 type 为 mode，此时，selectedVal[0] !== 'null'，就表示已经有选中值
    // - 如果 type 为 price，此时，selectedVal[0] !== 'null'，就表示有选中值
    //   如果 是 more
    let newStatus={...this.state.titleStatus}
    let selectedVal=val;// selectedVal值
    // 如果是area 并且 有值 area就选中
    if(type==='area'&&(selectedVal.length !== 2 || (selectedVal.length===2&&selectedVal[0] !== 'area')) ){
      newStatus[type]=true 
    }else if(type==='mode'&&selectedVal[0] !== 'null'){// 方式mode 并且有值
      newStatus[type]=true 
    }else if(type==='price'&&selectedVal[0] !== 'null'){// 租金 并且有值
      newStatus[type]=true 
    }else if(type==='more'&&selectedVal.length!==0){//筛选户型 并且有值
      newStatus[type]=true
    }else{
        newStatus[type]=false
    }

    //隐藏 只需要 把openType值重新变成 ''
    // 修改默认值 为新选择的
    this.setState({
      titleStatus:newStatus,// 修改 这次的判断 高亮
      openType:'',
      //修改默认值 为 确定时候选择的
      selectedValues:{
        ...this.state.selectedValues,
        [type]:val
      }
    },()=>{
      // 把条件传给houselist组件
      // console.log('全部的filter值',this.state.selectedValues)
      // 把拿到的数据 转换成 我们想要的数据
      /* 
      我们拿到的 数据
        { area: (3) ["subway"/area, "10号线", "SUY|2c596710-ab51-1836"]
        mode: ["true"]
        more: (2) ["ROOM|d4a692e4-a177-37fd", "ORIEN|141b98bf-1ad0-11e3"]
        price: ["PRICE|2000"]
        }

        我们需要的数据
        {
          area:'区域id',// 或者 subway:'地铁id',
          mode:'true',
          price:'price|2000',
          more:'一室,东,...'

        }
      */
      let newValues={...this.state.selectedValues}
      let filters={}
      // area  也 可能 是subway
      let areaName=newValues.area[0]
      let areaValue='null'
      if(newValues.area.length===3){// 选了值
          areaValue= newValues.area[2]!=='null'?newValues.area[2]:newValues.area[1]
      }
      filters[areaName]=areaValue
      filters.mode= newValues.mode[0];// 方式
      filters.more=newValues.more.join(',') //户型朝向more 把数组 以 , 拆分成 字符串
      filters.price=newValues.price[0]
      //传 到houselist组件
      this.props.onFilter(filters)
    })
   

  }
  /* 数据 area区域地铁 
   rentType整租合租  
   price租金 
    characteristic房屋亮点
    floor楼层
    oriented朝向 
    roomType房屋类型
    { area: {label: "区域", value: "area", children: Array(13)}
      characteristic: (13) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
      floor: (3) [{…}, {…}, {…}]
      oriented: (8) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
      price: (8) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
      rentType: (3) [{…}, {…}, {…}]
      roomType: (5) [{…}, {…}, {…}, {…}, {…}]
      subway: {label: "地铁", value: "subway", children: Array(23)}
    }
  */
  renderPicker=()=>{
      // 如果点击了 area区域 mode方式 price租金 就显示 否则不显示
      let { openType, filterdata,selectedValues }=this.state
      // if( area区域 mode方式 price租金 就显示){
      if(openType==='area' || openType==='mode'||openType==='price'){
        // 传递数据 --area就传area的数据 mode就传mode数据
        // let data=this.state.filterdata['price']
        // 判断到底 应该传 哪个数据 area mode price
        let data=[]
        let cols=3//默认3列
        let defaultValues=selectedValues[openType];// ["area", null]  ["null"]  ["null"]
        switch (openType) { 
          case 'area':
            data=[filterdata.area,filterdata.subway]
            cols=3
            break;
          case 'mode':
             data=filterdata['rentType']
             cols=1
             break;
          case 'price':
             data=filterdata['price']
             cols=1
          break;
        }

        return <FilterPicker key={openType} type={openType} defaultValues={defaultValues} data={data} cols={cols} onCancel={this.onCancel} onSave={this.onSave} />
      }
      // 否则不显示
      return null
  }
  // 显示 遮罩层
  renderMask=()=>{
    // 如果点击了 area区域 mode方式 price租金 就显示 否则不显示
    let {openType}=this.state
    if(openType==='area' || openType==='mode' || openType==='price'){
      return <div className={styles.mask} />
    }
    return null
    
  }
  // 显示 filtermore 户型朝向 组件
  renderMore=()=>{
    // 如果点击了筛选more 才显示 否则不显示
    let { openType , filterdata } =this.state
    let data={
      roomType:filterdata.roomType,
      oriented:filterdata.oriented,
      floor:filterdata.floor,
      characteristic:filterdata.characteristic
    }
    // 默认值
    let defaultValues=this.state.selectedValues.more
    if(openType==='more'){
       return <FilterMore onCancel={this.onCancel} defaultValues={defaultValues}  data={data} onSave={this.onSave} />
    }
    return null;
  }
  render() {
    // console.log('this.state.titleStatus',this.state.titleStatus)
    return (
      <div className={styles.root}>
        {/* 前三个菜单的遮罩层 */}
        {this.renderMask()}

        <div className={styles.content}>
          {/* 标题栏 */}
          <FilterTitle 
          titleStatus={this.state.titleStatus} 
          onTitleClick={this.onTitleClick}  />

          {/* 前三个菜单对应的内容： */}
          {this.renderPicker()}

          {/* 最后一个菜单对应的内容： */}
          {this.renderMore()}
        </div>
      </div>
    )
  }
}
