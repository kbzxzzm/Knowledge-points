import React from 'react'

import { Flex } from 'antd-mobile'

import styles from './index.module.css'

// 条件筛选栏标题数组：
const titleList = [
  { title: '区域', type: 'area' },
  { title: '方式', type: 'mode' },
  { title: '租金', type: 'price' },
  { title: '筛选', type: 'more' }
]

/* 
{
  area: false,//区域
  mode: false,//方式
  price: true,// 租金
  more: false //筛选more
}
*/

export default function FilterTitle(props) {
  // console.log('props',props)
  return (
    <Flex align="center" className={styles.root}>
      {/* 循环生成 四个标题 */}
      {titleList.map(item=>{
        // 判断 是否应该选中 props.titleStatus  item.type就是 area mode price more四个单词
         let isSelected=props.titleStatus[item.type]
          return <Flex.Item key={item.type}
          onClick={()=>{
            //点击 让当前的标题高亮 点area就让area变成true 点谁让谁变成true
            props.onTitleClick(item.type)
          }}
          >
            {/* 选中类名： selected  styles.selected */}
            <span className={[styles.dropdown,isSelected?styles.selected:'' ].join(' ')}>
              <span>{item.title}</span>
              <i className="iconfont icon-arrow" />
            </span>
          </Flex.Item>
      })}
      
    </Flex>
  )
}
