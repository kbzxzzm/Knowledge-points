import React, { Component } from 'react'

import FilterFooter from '../../../../components/FilterFooter'

import styles from './index.module.css'

export default class FilterMore extends Component {
  state={
    selectedValues: this.props.defaultValues //默认传进来
  }
  //点击span 每一个格子
  onSpanClick=(id)=>{
      //判断 如果数组没有 就加 如果数组有就取消 删除
      let newValues=[...this.state.selectedValues]
      // let index=newValues.indexOf(id) ;//找到 是索引  找不到 -1
      let index=newValues.findIndex(item=>item===id) ;//找到 是索引  找不到 -1
      if(index===-1){// 找不到 没有 push
        newValues.push(id)
      }else{
         newValues.splice(index,1);//splice(0,1) 从0索引开始 删除一个
      }
      // console.log('选择的more数组',newValues)
      //赋新值
      this.setState({
        selectedValues:newValues
      })
  }
  // 渲染标签 
  renderFilters(arr) {
    // 高亮类名： styles.tagActive
    // 选中值的数组里面 如果有 就代表选了 就应该高亮 没有 就不高亮
     // 每一个 盒子 循环生成很多span就行
    return arr.map(item=>{
        // 判断 当前的 有没有在 selectedValues数组里面 在就高亮  不在就不高亮
        // let  isSelected= this.state.selectedValues.indexOf(item.value)!==-1
        let  isSelected= this.state.selectedValues.includes(item.value) ;// includes有就 true 没有false
        return  <span 
              key={item.value}
              className={[styles.tag, isSelected?styles.tagActive:'' ].join(' ')}
              onClick={()=>{
                 this.onSpanClick(item.value)
              }}
              > 
                {item.label}
            </span>
      })
  }

  render() {
    return (
      <div className={styles.root}>
        {/* 遮罩层 让filter上的openType为 '' 就隐藏 */}
        <div className={styles.mask} onClick={()=>{
          //  console.log('1111')
          this.props.onCancel()
        }} />

        {/* 条件内容 */}
        <div className={styles.tags}>
          <dl className={styles.dl}>
            <dt className={styles.dt}>户型</dt>
            <dd className={styles.dd}>{this.renderFilters(this.props.data.roomType)}</dd>

            <dt className={styles.dt}>朝向</dt>
            <dd className={styles.dd}>{this.renderFilters(this.props.data.oriented)}</dd>

            <dt className={styles.dt}>楼层</dt>
            <dd className={styles.dd}>{this.renderFilters(this.props.data.floor)}</dd>

            <dt className={styles.dt}>房屋亮点</dt>
            <dd className={styles.dd}>{this.renderFilters(this.props.data.characteristic)}</dd>
          </dl>
        </div>

        {/* 底部按钮 */}
        <FilterFooter 
        className={styles.footer} 
        cancelText='清除' 
        onCancel={()=>{
            //清除 -- 把数组变成空就行
            this.setState({
              selectedValues:[]
            })
        }}
        onSave={()=>{
          //点击确定 传 选中的值 到filter父上面
          this.props.onSave('more',this.state.selectedValues)
        }}
         />
      </div>
    )
  }
}
