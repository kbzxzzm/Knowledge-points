import React, { Component } from 'react'

// 导入 顶部搜索导航栏
import SearchHeader from '../../components/SearchHeader'
// 导入 样式
import './houselist.scss'
import styles from './houselist.module.css'
// 导入选择 Filter组件
import Filter from './components/Filter'
// 导入 定位城市
import { getCurrentCity } from '../../utils'
// 导入API
import { API } from '../../utils/api'
// 导入 Sticky组件 用来吸顶 --固定定位
import Sticky from '../../components/Sticky'
// 导入可视区域渲染
import { List, AutoSizer, WindowScroller, InfiniteLoader } from 'react-virtualized';
// 导入Toast
import { Toast } from 'antd-mobile'

// 导入 NoHouse
import NoHouse from '../../components/NoHouse'

// 导入动画库
import { Spring } from 'react-spring/renderprops'


export default class Houselist extends Component {
  state = {
    cityname: '',
    id: '',
    list: [],// 房子数据
    count: 0, // 房子总数量
    isloaded: false// 还没有发
  }

  filters = {}

  async componentDidMount() {
    //获取定位城市
    let dingwei = await getCurrentCity()
    console.log('dingwei', dingwei)
    //赋值
    this.setState({
      cityname: dingwei.label,
      id: dingwei.value
    }, () => {
      //  this.filters={}
      // 当设置好城市id后  就发送请求获取 所有房子 
      this.gethouselist()
    })
  }
  // houselist里面 拿到条件 发送ajax
  onFilter = (filters) => {
    console.log('houselist组件的Filter', filters)
    this.filters = filters
    // 确定 筛选条件 跳到 页面顶部  从第一条开始了
    window.scrollTo(0, 0)
    // 发送ajax 获取 对应房子的数据
    this.gethouselist()
  }

  // 获取房子列表数据
  gethouselist = async () => {
    // http://localhost:8080/houses?cityId=AREA%7C88cff55c-aaa4-e2e0&area=AREA%7C88cff55c-aaa4-e2e0&rentType=true&price=null&more=CHAR%7C76eb0532-8099-d1f4%2CFLOOR%7C1%2CAREA%7C88cff55c-aaa4-e2e0%2CORIEN%7C61e99445-e95e-7f37%2Ctrue&roomType=ROOM%7Cd1a00384-5801-d5cd&oriented=ORIEN%7C61e99445-e95e-7f37&characteristic=CHAR%7C76eb0532-8099-d1f4&floor=FLOOR%7C1&start=1&end=20
    Toast.loading('正在加载...', 0)
    let res = await API.get("/houses", {
      params: {
        cityId: this.state.id,//城市
        ...this.filters,// 条件
        start: 1, //开始的数据
        end: 20// 结束的数据
      }
    })
    console.log('房子数据', res)
    Toast.hide()
    // 提示多少套房源
    if (res.data.body.count != 0) {
      Toast.info(`共有${res.data.body.count}套房源`, 2)
    }
    this.setState({
      list: res.data.body.list,
      count: res.data.body.count,
      isloaded: true // 发了ajax了
    })
  }
  // 渲染每一个列表item项
  rowRenderer = ({
    key, // 唯一key 必须有
    index, // 每项的索引  必须有
    isScrolling, //是否在滚动
    isVisible, // 是否可见
    style, // 每一项的样式 必须有
  }) => {
    // console.log('index',index)
    let item = this.state.list[index]
    // console.log('item',item);// 房子数据 有可能 滑动快了 还没有数据 就是undefined 可以判断一些
    if (!item) {// 还没有数据 
      return <div key={key} style={style} className='no' >
        房子正在加载.....
        </div>
    }

    return (
      // 每一个房子
      <div key={key} style={style} className={styles.house}
       onClick={()=>{
          // 点击每个房子 跳转到详情页
          this.props.history.push("/detail/"+item.houseCode)
       }}
      >
        <div className={styles.imgWrap}>
          <img className={styles.img} src={`http://localhost:8080${item.houseImg}`} alt="" />
        </div>
        <div className={styles.content}>
          <h3 className={styles.title}>{item.title}</h3>
          <div className={styles.desc}>{item.desc}</div>
          <div>
            {/* ['近地铁', '随时看房'] */}
            {item.tags.map((val, index) => {
              return <span key={index} className={[styles.tag, styles.tag1].join(' ')} >
                {val}
              </span>
            })}

          </div>
          <div className={styles.price}>
            <span className={styles.priceNum}>{item.price}</span> 元/月
              </div>
        </div>
      </div>
    );
  }
  // 当前这行是否有数据 有 true 没返回false
  isRowLoaded = ({ index }) => {
    //index 每一个索引  !!123 可以转换成 本身对应 true或者false
    return !!this.state.list[index];
  }
  //({ startIndex: number, stopIndex: number }): Promise. The returned Promise should be resolved once row data has finished loading
  // 是一个函数 参数是对象 有 startIndex stopIndex 索引   返回值是promise 必须resolve 一次代表数据加载好了
  // 发送请求 加载更多
  loadMoreRows = ({ startIndex, stopIndex }) => {
    // startIndex 开始的索引20  stopIndex结束的索引29 就加载20-29的十条数据
    // console.log('startIndex',startIndex,'stopIndex',stopIndex)
    return new Promise((resolve, reject) => {
      // 必须resolve 一次
      API.get("/houses", {
        params: {
          cityId: this.state.id,//城市
          ...this.filters,// 条件
          start: startIndex, //开始的数据
          end: stopIndex// 结束的数据
        }
      }).then((res) => {
        console.log('加载更多房子数据', res);// res.data.body.list 新的10条 追加到原来的list里面 
        let newlist = [...this.state.list, ...res.data.body.list]
        this.setState({
          list: newlist
        })

        resolve();// 必须resolve 一次代表数据加载好了
      })


    })
  }
  // 渲染房子列表
  renderlist = () => {
    // 如果没有房子 就显示 没有房子 
    // 默认进来就是0 所以 应该 ajax成功之后 count是0 才叫真的 没有房子
    if (this.state.count === 0 && this.state.isloaded === true) { //没有房子并且 是ajax成功之后 count 0代表 才叫真的 没有房子
      return <NoHouse>
        没有对应的房子哦~~请换个条件吧~~
        </NoHouse>
    }
    // 有房子 就显示列表
    return <InfiniteLoader
      isRowLoaded={this.isRowLoaded} //判断当前房子是否加载完
      loadMoreRows={this.loadMoreRows}// 加载更多
      rowCount={this.state.count} //总条数
    >
      {({ onRowsRendered, registerChild }) => (
        <WindowScroller>
          {({ height, isScrolling, onChildScroll, scrollTop }) => (
            <AutoSizer>
              {({ width }) => (
                <List
                  onRowsRendered={onRowsRendered} // 滚动的列表 必须加上 才能知道谁滚动
                  ref={registerChild} // ref可以知道应该 更新哪个列表数据
                  autoHeight // 自适应高度 WindowScroller 必须加上
                  width={width}
                  height={height}
                  isScrolling={isScrolling} // 是否正在滚动
                  onScroll={onChildScroll} // 滚动事件
                  scrollTop={scrollTop} // 滚动出去的距离
                  rowCount={this.state.count} // 总条数
                  rowHeight={120}
                  rowRenderer={this.rowRenderer}
                />
              )}
            </AutoSizer>
          )}
        </WindowScroller>
      )}
    </InfiniteLoader>
  }
  render() {
    return (
      <div className="houselist">

        {/* 顶部搜索导航栏  透明度 变化的动画  */}
        <Spring 
            from={ { opacity: 0 }  } 
            to={ { opacity: 1 } }>

                  { 
                    (props) => {
                      // 这里就是 要动画的内容
                      return <div style={props} className="header">
                        <i className="iconfont icon-back"></i>
                        <SearchHeader cityname={this.state.cityname}></SearchHeader>
                      </div>
                    }
                  }

          </Spring>

        {/* 选择筛选房子 Filter  封装Sticky组件 */}
        <Sticky height={40}>
          <Filter onFilter={this.onFilter}></Filter>
        </Sticky>

          {/* 测试动画 */}
          {/* 在组件Spring之间 写了一个函数  他封装的时候在里面 this.props.children() */}
          {/* form 初始的样式 {样式名:值...}  to 动画结束的样式 {样式名:值...}  */}
         {/*  <Spring 
            from={ { opacity: 0 }  } 
            to={ { opacity: 1 } }>

                  { 
                    (props) => {
                      // 这里就是 要动画的内容
                      return <div style={props}>啊啊啊啊啊啊啊</div>
                    }
                  }

          </Spring> */}

          {/* <Spring
            from={{
              width: 100,
              padding: 0,
              background:
                'linear-gradient(to right, #30e8bf, #ff8235)',
              transform:
                'translate3d(400px,0,0) scale(2) rotateX(90deg)',
              boxShadow: '0px 100px 150px -10px #2D3747',
              borderBottom: '0px solid white',
              shape: 'M20,380 L380,380 L380,380 L200,20 L20,380 Z',
              textShadow: '0px 5px 0px white'
            }}
            to={{
              width: 'auto',
              padding: 20,
              background:
                'linear-gradient(to right, #009fff, #ec2f4b)',
              transform:
                'translate3d(0px,0,0) scale(1) rotateX(0deg)',
              boxShadow: '0px 10px 20px 0px rgba(0,0,0,0.4)',
              borderBottom: '10px solid #2D3747',
              shape: 'M20,20 L20,380 L380,380 L380,20 L20,20 Z',
              textShadow: '0px 5px 15px rgba(255,255,255,0.5)'
            }}>
            {props => <div style={props}>啊啊啊啊啊啊啊</div>  }
          </Spring> */}

        {/* 房子列表 */}
        {/*WindowScroller 让整个页面 一起滚动  */}
        {/*InfiniteLoader 让页面无限滚动 加载更多数据 */}
        {this.renderlist()}



        {/* <InfiniteLoader
            isRowLoaded={isRowLoaded}
            loadMoreRows={loadMoreRows}
            rowCount={this.state.count} //总条数
          >
            {({ onRowsRendered, registerChild }) => (
              <List
                height={200}
                onRowsRendered={onRowsRendered}
                ref={registerChild}
                rowCount={remoteRowCount}
                rowHeight={20}
                rowRenderer={rowRenderer}
                width={300}
              />
            )}
          </InfiniteLoader> */}


      </div>
    )
  }
}
