import React from 'react';

// 导入 antd-mobile 组件
import { Button } from 'antd-mobile';
// App里面配置基本路由
import { BrowserRouter as Router , Route ,Link,Redirect} from 'react-router-dom'
// 导入自己写的组件: 建议大家 一个组件创建一个文件夹 首字母大写 里面写index.js
import Home from './pages/Home'
import Citylist from './pages/Citylist'
import Map from './pages/Map'
import HouseDetail from './pages/HouseDetail'
import Login from './pages/Login'

import Rent from './pages/Rent'
// 导入封装好的 AuthRoute
import  AuthRoute from './components/AuthRoute'
// /home 主页  /citylist 城市选择
class App extends React.Component {
   render(){
     return <Router>
          <div className="App">
                {/* <h1>app根组件</h1> */}
                {/* 使用 */}
                {/* 重定向 / 跳转到 /home/index */}
                <Route 
                  exact
                  path="/" 
                  render={(props)=>{
                      return <Redirect to="/home/index"></Redirect>
                  }} />
                {/* 配置路由 挖坑 */}
                <Route path="/home" component={Home}></Route>
                <Route exact path="/citylist" component={Citylist}></Route>
                {/* 地图组件 */}
                <Route exact path="/map" component={Map}></Route>
                {/* 房子详情页面  
                    /detail/12   12就是id
                    /detail/:id 路由参数 访问 detail组件
                       
                */}
                <Route exact path="/detail/:id"  component={HouseDetail}></Route>
                {/*  /login 显示Login */}
                <Route exact path="/login"  component={Login}></Route>
                {/* exact true 精确匹配 false是模糊 
                只不过一般我们 直接写exact 默认就是true */}
                {/* 使用AuthRoute 我们只是封装了 代码和刚才是一样的 
                  后面 凡是 需要 判断是否登录的页面 就直接用封装好的
                   AuthRoute 来 替代 Route 就行
                */}
                <AuthRoute exact={true} path='/rent' Yemian={Rent} ></AuthRoute>

                {/* <AuthRoute path='/add' Yemian={ADD}></AuthRoute> */}
                {/* 要求 /rent  访问  房屋管理 rent组件
                   /rent/add 这个也需要 判断
                   有很多页面 都需要 判断 就封装一下 AuthRoute
                    AuthRoute鉴权路由组件
                 */}
                {/* 第一种写法 */}
                {/* <Route exact path="/rent" component={Rent}></Route> */}
                {/* 第二种写法 */}
                {/* <Route 
                  exact
                  path="/rent" 
                  render={(props)=>{
                      // 这种写法的好处是？ 我们可以在这里面做if判断
                      // 显示的组件 如果登录了token 就正常显示页面组件 如果没有登录 就跳转到 /login
                      if( isAuth() ){ //isAuth() true 登录 正常显示页面组件
                        return <Rent></Rent>
                      }else{ //没有登录  重新跳转到 /login 页面
                          return <Redirect to="/login"></Redirect>
                      }
                      
                  }} /> */}



          </div>
     </Router>
    
   }
}

export default App;
