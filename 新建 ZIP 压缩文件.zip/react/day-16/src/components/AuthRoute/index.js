import React, { Component } from 'react'

// 如果登录了token 就正常显示页面组件 如果没有登录 就跳转到 
// 封装一下  因为很多页面需要判断 而且代码 都是Route这段代码
// 封装 需要 导入对应 用到的东西
import {Route,Redirect} from 'react-router-dom'
import { isAuth } from '../../utils/token'

export default class AuthRoute extends Component {
  render() {
    console.log('this.props',this.props)
    // 传来的 组件 首字母大写 因为是组件 要求
    let { Yemian ,path ,exact }=this.props
    return <Route 
              exact={exact} // 不写死 
              path={path} // 路由也不能写死 因为有很多都需要
              render={(props)=>{
                  // 这种写法的好处是？ 我们可以在这里面做if判断
                  // 显示的组件 如果登录了token 就正常显示页面组件 如果没有登录 就跳转到 /login
                  if( isAuth() ){ //isAuth() true 登录 正常显示页面组件
                    //不要写死rent组件 我需要 你传什么页面组件  我就显示什么页面组件
                    return <Yemian></Yemian>
                  }else{ //没有登录  重新跳转到 /login 页面
                      return <Redirect to="/login"></Redirect>
                  }
                  
            }} />
  }
}
