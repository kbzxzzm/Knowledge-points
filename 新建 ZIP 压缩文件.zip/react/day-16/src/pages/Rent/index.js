import React, { Component } from 'react'

export default class Rent extends Component {
  render() {
    return (
      <div>
           我是rent组件
      </div>
    )
  }
}
