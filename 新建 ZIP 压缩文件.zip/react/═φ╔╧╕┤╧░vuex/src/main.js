import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false
// 导入封装的组件 全局注册
// Vue.component('my-swiper',组件)
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
