<template>
  <div>
    <!-- v-for 循环 图片  还要写上定时器 -->
     <ul>
        <li>图片1</li>
        <li>图片2</li>
        <li>图片3</li>
     </ul>
  </div>
</template>

<script>
// 轮播图 有一个  时间  应该 传几秒 就 定时器是几秒
// 封装的组件 需要 1 接受传来的参数  2 验证参数类型 3 如果没传要有默认值
export default {
  props:{
     time:{
       type:Number,
       default:3000
     }
  }
}
</script>

<style>
/* 样式 */
</style>