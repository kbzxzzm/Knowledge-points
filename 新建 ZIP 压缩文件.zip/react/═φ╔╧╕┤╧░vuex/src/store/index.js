import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    count:1//count相当于data里面的数据 但是是全局的 就是 全部组件都可以拿到了 $store
  },
  mutations: {
    increment (state,num) {
      console.log('mutation触发')
      // 变更状态
      // state.count++
      state.count=state.count+num
    }
  },
  actions: {
    // actionAdd (context,num) {
    //   // context对象 有commit 用来触发 mutation
    //    console.log('action的函数actionAdd')
    //    console.log('context',context)
    //   //  context.commit(mutation函数名,参数..)
    //   context.commit('increment',num)
    // }
    actionAdd ({commit},num) {
      //异步 发送ajax  拿到数据 再触发mutation修改
      // context对象 有commit 用来触发 mutation
       console.log('action的函数actionAdd')
      //  console.log('context',context)
      //  context.commit(mutation函数名,参数..)
      commit('increment',num)
    }
  },
  modules: {
  }
})
// 四次挥手，别名连接终止协议 (浏览器请求关闭连接)
// 1 下载并导入 vuex包
// 2 Vue.use(Vuex)
// 3 new Vuex.Store({state全局数据})
// 4 需要在new Vue的时候使用  挂载
// new Vue({
//   router,
//   store,
// })
// 修改store全局数据 
// dispatch 触发action ---> commit触发 mutation --》在mutation里面才可以修改state
// 必须 在mutation里面才可以修改state 

// websocket  :https://www.runoob.com/html/html5-websocket.html
