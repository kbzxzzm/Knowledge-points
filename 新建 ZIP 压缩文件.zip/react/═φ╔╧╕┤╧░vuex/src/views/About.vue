<template>
  <div>
    <!-- 1 新建一个 Swiper.vue -->
    <!-- 2 在main.js全局注册或者组件内部局部注册 -->
    <!-- 3 使用 自己封装的组件标签 -->
    <!-- <my-swiper time='1000'></my-swiper> -->
    <h1>about用到的全局数据 {{$store.state.count}} </h1>
  </div>
</template>

<script>
export default {
    // 组件中 data 为什么是函数 返回新对象？
    // 组件 如果使用 5次  函数形式 每次都是返回新对象 不会互相影响
    // 如果不是  函数写法  地址都是一样的  会互相影响
    name:'about',
    data(){
       return {
          name:"about啊"
       }
    }
    // data:{
    //   name:"about啊"
    // }
}
</script>

<style>

</style>
