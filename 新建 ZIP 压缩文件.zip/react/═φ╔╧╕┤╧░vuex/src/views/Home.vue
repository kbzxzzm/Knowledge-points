<template>
  <div class="home">
     <h1>count的值:  {{$store.state.count}} </h1>
     <button @click="add">点击按钮让全局count+1</button>
  </div>
</template>

<script>

// 只要你安装步骤写好了 store全局数据
//  那么在 任何组件 都有 html范围 $store js范围 this.$store
export default {
  name: 'home',
  data(){
    return {
       a:1
    }
  },
  created(){
    console.log('全局数据',this.$store)
  },
  methods:{
    add(){
      // this.$store.dispatch(action函数名,参数..)
      console.log('点了')
      // this.$store.dispatch('actionAdd',10)
      // 修改全局数据 正常情况：
      // 1 先dispatch action函数 
      // 2 在action里面 commit触发mutation
      // 3 在mutation里面 才能修改全局数据 (不管怎么样 一定要有mutation)
      // 没有异步 可以直接找mutation
       this.$store.commit("increment",10)
        // 注意点 
        // 1 如果有异步 需要在action写异步操作 
        // 2 mutation必须写同步操作 一般只用来直接修改state
        // 3 如果没有涉及到异步操作 其实你可以跳过action 直接触发mutation
        // 4 但是 你是不能直接修改state 必须最少要由mutation修改
    }
  },
  computed:{}


}
</script>

<style>
/* // less  需要下载less-loader
// .box{
//   div{
    
//   }
// } 
// scss  需要下载 sass-loader  node-sass
// .box{
//   div{
    
//   }
// }

// stylus  需要下载 stylus-loader   stylus是以 缩进当 {} 
// .box
//   div
//     color:red; */
</style>


