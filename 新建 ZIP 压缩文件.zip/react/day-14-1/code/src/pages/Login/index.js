import React, { Component } from 'react'
import { Flex, WingBlank, WhiteSpace,Toast } from 'antd-mobile'

import { Link } from 'react-router-dom'

import NavHeader from '../../components/NavHeader'

import styles from './index.module.css'
import { API } from '../../utils/api'
// 验证规则：
// const REG_UNAME = /^[a-zA-Z_\d]{5,8}$/
// const REG_PWD = /^[a-zA-Z_\d]{5,12}$/
// 受控表单  被state数据绑定控制的表单
class Login extends Component {
  state={
     username:'',
     password:''
  }
  //点击登录按钮 获取用户名密码 发送ajax请求 成功就登录成功了
  handlesubmit=async (e)=>{
    // 不想刷新  阻止默认行为 
    e.preventDefault()
    //1 获取用户名和密码 
    // react是没有v-model指令的 需要自己去写 react怎么绑定文本框的？1 文本框绑定value  2 onChange值改变去重新赋值
    console.log('username用户名',this.state.username,'password密码',this.state.password);// 默认submit 会刷新
    
    //2 判断用户名密码是否为空 是否格式正确
    //  用户名 必须 5 -8 位  需要正则表达式
    //  密码   必须  5-12位  需要正则表达式
    // /^ 正则表达式 $/
    //  正则.test(要匹配的值) 满足匹配 返回true 不满足返回false
    let resuser=/^\w{5,8}$/
    if(this.state.username===''|| !resuser.test(this.state.username) ){
      Toast.info("用户名不能为空或者不符合",1)
      return;// 后面代码不要执行了
    }
    let regpass=/^\w{5,12}$/
    if(this.state.password==='' || !regpass.test(this.state.username) ){
      Toast.info("密码不能为空或者不符合",1)
      return;
    }

    //3 去 发送 ajax 登录  // http://localhost:8080/user/login 
    let res=await API.post("/user/login",{
       username:this.state.username,
       password:this.state.password
    })
    console.log('登录结果',res)// 错误是400 成功是200 还返回了token
    if(res.data.status===200){
       Toast.success('登录成功', 1)
      //  登录成功 会有  token  后期如果没有token 就代码 没有登录 
       console.log('token',res.data.body.token)
      //  把token存起来 后面好用 
      localStorage.setItem("my-token",res.data.body.token)
      // eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6NSwiaWF0IjoxNTgwODg0Mjk1LCJleHAiOjE1ODA4OTg2OTV9.pMuaGK_QGesHRF5foXaSKevVe3mMt_eWzo9d5fzxAa0
      // token 本质上 就类似 一段随机乱码的唯一的字符串 作为密钥 判断是否登录
      // 我们发生ajax  后台返回给我们token 问题 后台怎么生成的token?
      //   后台随机生成一段token字符串给我们是可以的  
      //   但是 现在后台一般使用 jwt 方式生成  json web token 前端的token

    }else{
      Toast.fail('失败啦~！', 1)
    }
  }
  // 获取设置 用户名
  getusername=(e)=>{
    // console.log('事件源',e.target)
    // console.log('用户名',e.target.value)
    // 重新赋值
    this.setState({
      username:e.target.value
    })
  }
  // 获取设置密码
  getpassword=(e)=>{
    // console.log('密码',e.target.value)
    // 重新赋值
    this.setState({
      password:e.target.value
    })
  }
  render() {
    return (
      <div className={styles.root}>
        {/* 顶部导航 */}
        <NavHeader className={styles.navHeader}>账号登录</NavHeader>
        <WhiteSpace size="xl" />

        {/* 登录表单 */}
        <WingBlank>
          <form onSubmit={this.handlesubmit}>

            <div className={styles.formItem}>
              <input
                value={this.state.username}
                onChange={this.getusername}
                className={styles.input}
                name="username"
                placeholder="请输入账号"
              />
            </div>
            {/* 长度为5到8位，只能出现数字、字母、下划线 */}
            {/* <div className={styles.error}>账号为必填项</div> */}
            <div className={styles.formItem}>
              <input
                value={this.state.password}
                onChange={this.getpassword}
                className={styles.input}
                name="password"
                type="password"
                placeholder="请输入密码"
              />
            </div>
            {/* 长度为5到12位，只能出现数字、字母、下划线 */}
            {/* <div className={styles.error}>账号为必填项</div> */}
            <div className={styles.formSubmit}>
              <button className={styles.submit} type="submit">
                登 录
              </button>
              {/* 如果button不是  type="submit" 那么  是普通按钮 触发 onclick点击事件*/}
              {/* 如果button  type="submit" 叫提交按钮会提交表单刷新 
                                触发 form 标签的 onsubmit事件 */}
            </div>
          </form>
          <Flex className={styles.backHome}>
            <Flex.Item>
              <Link to="/registe">还没有账号，去注册~</Link>
            </Flex.Item>
          </Flex>
        </WingBlank>
      </div>
    )
  }
}

export default Login
