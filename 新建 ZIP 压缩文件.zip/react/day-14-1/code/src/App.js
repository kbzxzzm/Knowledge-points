import React from 'react';

// 导入 antd-mobile 组件
import { Button } from 'antd-mobile';
// App里面配置基本路由
import { BrowserRouter as Router , Route ,Link,Redirect} from 'react-router-dom'
// 导入自己写的组件: 建议大家 一个组件创建一个文件夹 首字母大写 里面写index.js
import Home from './pages/Home'
import Citylist from './pages/Citylist'
import Map from './pages/Map'
import HouseDetail from './pages/HouseDetail'
import Login from './pages/Login'
// /home 主页  /citylist 城市选择
class App extends React.Component {
   render(){
     return <Router>
          <div className="App">
                {/* <h1>app根组件</h1> */}
                {/* 使用 */}
                {/* 重定向 / 跳转到 /home/index */}
                <Route 
                  exact
                  path="/" 
                  render={(props)=>{
                      return <Redirect to="/home/index"></Redirect>
                  }} />
                {/* 配置路由 挖坑 */}
                <Route path="/home" component={Home}></Route>
                <Route exact path="/citylist" component={Citylist}></Route>
                {/* 地图组件 */}
                <Route exact path="/map" component={Map}></Route>
                {/* 房子详情页面  
                    /detail/12   12就是id
                    /detail/:id 路由参数 访问 detail组件
                       
                */}
                <Route exact path="/detail/:id"  component={HouseDetail}></Route>
                {/*  /login 显示Login */}
                <Route exact path="/login"  component={Login}></Route>

          </div>
     </Router>
    
   }
}

export default App;
