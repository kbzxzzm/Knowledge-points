// 配置axios并导出
import axios from 'axios'

// console.log("地址",process.env.REACT_APP_URL)
import { BASE_URL } from './url'
// axios.defaults.baseURL='http://localhost:8080'
let API=axios.create({
  baseURL:BASE_URL
})
//API 就是配置了 url的 axios
export { API }