import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import * as serviceWorker from './serviceWorker'
import { Provider } from 'react-redux'
// .store.js专门暴露一个store对象

// 仓库模块
// createStore方法
import { createStore } from 'redux'



const initstate = {
  num: 10
}

const createReducer = (state, action) => {
  switch (action.type) {
    case 'add':
      let state1 = Object.assign({}, state)
      state1.num++
      return state1
    case 'sub':

    default:
      return state
  }
}

let store=createStore(createReducer, initstate)



// console.log(store)

// react-redux包的使用的第一步
// a. 属性传值给Provider组件
// b. Provider包裹App组件

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
)

serviceWorker.unregister()
