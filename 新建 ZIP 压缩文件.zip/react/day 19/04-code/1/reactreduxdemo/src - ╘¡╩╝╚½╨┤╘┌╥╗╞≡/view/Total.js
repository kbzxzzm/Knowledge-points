import React from "react";

import { connect } from "react-redux";

class Total extends React.Component {
  render() {
    // 总数的值来源于store里面的state(num1+num2+num3)
    // -> 在组件中使用redux中的store的state数据->组件中使用数据->利用react-redux插件帮我们简化代码->看文档

    // console.log(this.props) // {}->  {age:10}
    const { total } = this.props;

    // store.getState(
    return <div>商品总数：【{total}】</div>;
  }
}

// mapStateToProps
// 1. connect(实参1)->实参1是一个函数
// 2. mapStateToProps的形参有2个
// 2.1 state->store里面的state数据
// 2.2 ownProps->当前组件自己的属性数据
// 3. mapStateToProps函数有返回值
// 3.1 返回值是对象
// 3.2 返回的对象里面的key就是当前组件自己的porps的新数据->this.props.age
const mapStateToProps = (state, ownProps) => {
  // console.log(state)

  // const total = state.num1 + state.num2 + state.num3
  // state-> {num1:10,num2:20,num3:30}

  // for (const key in state) {
  //   total += state[key]
  // }

  // const temp = Object.values(state)
  // temp.forEach(item => {
  //   total += item
  // })

  // 1行代码
  // const str = Object.values(state).join('+') // [10,20,30] -> 10+20+30
  // console.log(str) // "10+20+30"    ->  10+20+30->识别读取字符串中的表达式
  // console.log(eval('10+20'))
  // eval()-> 可以识别字符串中的表达式
  let total = eval(Object.values(state).join("+"));

  return {
    total
  };
};

// export default connect(实参)(Total)
// connect其实是HOC函数
export default connect(mapStateToProps)(Total);
