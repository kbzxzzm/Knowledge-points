import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

// 2 
import { Provider } from 'react-redux'
// .store.js专门暴露一个store对象
// 仓库模块
// createStore方法
import { createStore } from 'redux'



// 全局数据
const initstate = {
  num: 100,
  username:"雷俊草",
  stu:'学生'
}

/*  {
  type: 'add',
  zhi:10
}
*/
const createReducer = (state, action) => {
  // state 就是全局数据  action 就是你触发的action
  console.log('fn1触发了action 来到reducer--state数据',state)
  console.log('fn1触发了action 来到reducer--action数据',action)
  // action.type  add
  // reducer函数 接受action判断做什么操作 就操作修改 state全局数据
  switch (action.type) {
    case 'add':
      let state1 = Object.assign({}, state)
      state1.num++
      return state1
    case 'jian':
        console.log('做减 操作')
        return state;
        break;
        
        // ....
    default:
      return state
  }


}

// let store=createStore(reducer函数,全局数据对象)
// 创建 一个全局 数据  store 
// 3 创建store  1 写上全局数据对象 
//            2 顺便写一个 reduder函数 reducer函数 判断做什么操作 就操作修改 state全局数据
let store=createStore(createReducer, initstate)



// console.log(store)

// react-redux包的使用的第一步
// a. 属性传值给Provider组件
// b. Provider包裹App组件

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
)

