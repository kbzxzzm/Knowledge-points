import React from 'react'
import { connect } from 'react-redux'


class Item extends React.Component {
  render() {
    console.log('组件的props',this.props)
    const { xx, pname, fn1, fn2 ,my ,stu } = this.props

    return (
      <div>
        {/* 
          按钮的处理函数->修改数据->修改state数据->在组件中修改state数据
        */}
        <button
          onClick={() => {
            // 点击 +  让全局数据 +1
            fn1()
          }}
        >
          +
        </button>
        <button
        onClick={()=>{
          //  修改全局 就需要 触发 
          this.props.jian()
        }}
        >
          -
        </button>
        {/* 
        商品名->来源于组件的使用位置->来源于组件自己的props->this.props.pname
        商品数量->来源于store的state->组件中要使用store的state数据
        */}
        <span>
          【传智书】---商品的数量【{xx}】 ---名字 :{my}--{stu}
        </span>
      </div>
    )
  }
}
// export default Item

// mapStateToProps 把state数据 对应到 props上 这样就可以直接在 props上拿数据了
// mapStateToProps 1 是一个函数 接受state参数
//                 2 在函数 return { 名字：全局数据 ... }
const mapStateToProps = (state, ownProps) => {
  // state 就是全局的数据 ownProps 是 组件的props 没有什么用
  console.log('全局state',state)
  return {
    // props上的名字:全局数据 这样 就可以在组件里面直接使用 对应名字 代表全局数据了
    xx: state.num,
    my:state.username,
    stu : state.stu
  }
}


// mapDispatchToProps : 把 dispatch相关的函数 对应到 组件的props 在组件使用props就行
// mapDispatchToProps 1 是一个函数  接受 dispatch 参数
//                    2 返回 return { 函数名:函数(函数里面使用 dispatch() ) ..  }

// addNum 这就是 action
/* 
   action 是一个对象 
   {
     type:"操作单词",//必须有type
     参数1:值,
     参数2：值
     ....
   }
*/
const addNum = {
  type: 'add',
  zhi:10
}
// dispatch 触发action ---》触发 reducer--》在reducer里面修改数据
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    // props上的函数名: 函数(函数里面使用 dispatch() )
    fn1: () => {
        // 1 点击+ 执行 fn1 
        // 2  fn1里面  dispatch(addNum的action)
        // 3 action触发就去到reducer
        dispatch(addNum)
    },
    // 触发dispatch去 减 
    jian:()=>{
      // dispatch(action操作)
      let jianAction={
        type:"jian",
        shuzi:9
      }
      dispatch(jianAction)
    }
  }
}


// connect 很像 withRoute  高价组件：本来是 Item
// 记住：react-redux里面  哪个组件要用全局数组 就用 connect 包裹 才可以 才能有
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Item)
