import React from 'react'


// 组件要用 就 先导入connect 并且 connect()(组件)
import { connect } from 'react-redux'

class Total extends React.Component {
  render() {
    // 总数的值来源于store里面的state(num1+num2+num3)
    // -> 在组件中使用redux中的store的state数据->组件中使用数据->利用react-redux插件帮我们简化代码->看文档

    // console.log(this.props) // {}->  {age:10}

    // store.getState(
     return <div>商品总数：{this.props.xx}</div>
  }
}

// mapStateToProps 函数用来 对应全局数据的使用
// mapDispatchToProps 用来对全局数据 增删改查操作的
let mapStateToProps=(state,ownProps)=>{
  // state 全局数据
  return {
    //  props上的名字:全局数据
    xx:state.num
  }
}

let mapDispatchToProps=(dispatch,ownProps)=>{
    return {
      // props用的函数名:函数 ( 函数要dispatch(action) )
    }
}
// export default Total
export default connect(mapStateToProps,mapDispatchToProps)(Total)
