import React from 'react'
import { connect } from 'react-redux'


class Item extends React.Component {
  render() {
    const { num, pname, fn1, fn2 } = this.props

    return (
      <div>
        {/* 
          按钮的处理函数->修改数据->修改state数据->在组件中修改state数据
        */}
        <button
          onClick={() => {
            fn1()
          }}
        >
          +
        </button>
        <button
        >
          -
        </button>
        {/* 
        商品名->来源于组件的使用位置->来源于组件自己的props->this.props.pname
        商品数量->来源于store的state->组件中要使用store的state数据
        */}
        <span>
          【传智书】---商品的数量【{num}】
        </span>
      </div>
    )
  }
}

// mapStateToProps->把state数据映射(改为)当前组件的props数据
const mapStateToProps = (state, ownProps) => {
  return {
    num: state.num
  }
}
const addNum = {
  type: 'add',
  zhi:10
}
// mapDispatchToProps
// 1. 函数
// 2. 形参1->dispatch方法
// 3. 形参2->ownProps
// 4. return {组件的新属性}
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    fn1: () => {
        dispatch(addNum)
    }
  }
}
// const mapDispatchToProps = (dispatch, ownProps) => {
//   return {
//     dispatch1: () => {
//       dispatch(actionCreator)
//     }
//   }
// }
// const mapDispatchToProps = (dispatch, ownProps) => {
//   return {
//     fn1: () => {
//        //一秒后修改
//       setTimeout(()=>{
//         dispatch(ACTION.addNum(ownProps.pname))
//       },1000)
//     },
//     fn2: () => {
//       dispatch(ACTION.subNum(ownProps.pname))
//     }
//   }
// }
// connect
// 1. HOC函数
// 2. 形参1->mapStateToProps->把state映射为props
// 3. 形参2->mapDispatchToProps->把修改state的dispatch映射为props

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Item)
