import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import { Provider } from 'react-redux'
// .store.js专门暴露一个store对象

import store from './store/store.js'
import * as serviceWorker from './serviceWorker'

// console.log(store)

// react-redux包的使用的第一步
// a. 属性传值给Provider组件
// b. Provider包裹App组件

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
)

serviceWorker.unregister()
