import React, { Component } from 'react'
import Cart from './view/Cart'
class App extends Component {
  render() {
    // App根组件中使用购物车组件Cart
    return <Cart />
  }
}

export default App
