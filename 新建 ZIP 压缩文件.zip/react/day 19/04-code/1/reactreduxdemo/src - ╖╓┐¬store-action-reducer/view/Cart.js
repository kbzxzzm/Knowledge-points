import React from 'react'
import Item from './Item'
import Total from './Total'

class Cart extends React.Component {
  render() {
    return (
      <div>
        <h2>购物车</h2>
        <hr />
        {/* Item->商品组件 */}
        <Item pname="num1" />
        <hr />
        {/* 总数组件 */}
        <Total />
      </div>
    )
  }
}

export default Cart
