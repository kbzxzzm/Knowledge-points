// actions模块

// export const addNum = () => {
//   return {
//     type: 'add',
//     zhi:10
//   }
// }

export const addNum = {
  type: 'add',
  zhi:10
}