// reducer模块

export const createReducer = (state, action) => {
  switch (action.type) {
    case 'add':
      let state1 = Object.assign({}, state)
      state1.num++
      return state1
    case 'sub':

    default:
      return state
  }
}
