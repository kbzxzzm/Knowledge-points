// 仓库模块
// createStore方法

import { createStore } from 'redux'

// reducer函数
import { createReducer } from './reducer.js'

const state = {
  num: 10
}

export default createStore(createReducer, state)
