import React, { createRef } from 'react'

export default (props) => {

  return (
    <>
      <input />
      <button
      >
        ADD
      </button>
    </>
  )
}
