// 展示组件

import React from 'react'

// reducer->switch->return新状态->执行组件中的connect方法->mapStateToProps->映射新state为props
export default (props) => {
  let list=[]
  // if (list.length === 0) return <p>暂无数据</p>
  // 遍历->需要数据数组->原来的数组是state里面的list->现在组件的数据数组->交给redux的store的state->视图层使用数据层->利用react-redux的connect
  return (
    <ul>
     
        <li>
          <span
            style={{ textDecoration:  'line-through' }}
          >
            打女朋友
          </span>
          <button>X</button>
        </li>
    </ul>
  )
}

// 当前的列表组件的内容有两部分
// 1. React组件->函数组件->JSX标签
// 2. 容器组件->来源于react-redux的connect的加工->返回的处理state,使用redux的代码

/*
const handleToggle = ID => {
    // props.dispatch(toggletodo(ID))
    toggle(ID)
  }

  const handleDele = ID => {
    // props.dispatch(deletetodo(ID))
    dele(ID)
  }

*/
