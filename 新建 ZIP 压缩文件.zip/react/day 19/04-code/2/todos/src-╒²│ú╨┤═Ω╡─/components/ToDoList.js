// 展示组件
import React from 'react'
// reducer->switch->return新状态->执行组件中的connect方法->mapStateToProps->映射新state为props
// 在 list组件要用 就导入connect 包裹list组件
import { connect } from 'react-redux'

let List= (props) => {
  console.log('list组件的props',props)
  let { mylist }=props
  if (mylist.length === 0) return <p>暂无数据</p>
  // 遍历->需要数据数组->原来的数组是state里面的list->现在组件的数据数组->交给redux的store的state->视图层使用数据层->利用react-redux的connect
//  获取全局数据的list  循环生成对应的很多li 
  return (
    <ul> 
      {/* 循环mylist 生成很多li */}
      {mylist.map(item=>{
          return <li key={item.id}>
              <span
                style={{ textDecoration:  item.isfinish ? 'line-through' : '' }}
              >
                {item.name}
              </span>
              {/* 点击X 删除全局数据list  对应的那个数据  */}
              <button onClick={()=>{
                  // 现在数据是全局的 不能直接删 要执行mapDispatch的函数 去触发action
                  props.deletetodo(item.id)
              }}>X</button>
            </li>
      })}
        
    </ul>
  )
}
// mapStateToProps 函数 使用全局数据 把全局数据对应到props 上 在组件之间用props就可以获取全局数据
// mapDispatchToProps 函数 对全局数据增删改查操作的 把对应的函数 放到props上
let mapStateToProps=(state,ownProps)=>{
  // state 就是全局数据对象
  return {
    // props上的名字:全局数据
    mylist:state.list
  }
}
// 暂时没有操作 我空着 空对象就行
let mapDispatchToProps=(dispatch,ownProps)=>{
    return {
      //  函数名:函数
      deletetodo:(id)=>{
        console.log('mapdispatch的函数',id)
        // 在这里面 dispatch 触发 action -->action到reducer-->在reducer里面删除数据
        let deleteAction={
          type:"del",
          id:id
        }
        // dispatch(删除的action)
        dispatch(deleteAction)
      }
    }
}
// export default List
export default connect(mapStateToProps,mapDispatchToProps)(List)










// 当前的列表组件的内容有两部分
// 1. React组件->函数组件->JSX标签
// 2. 容器组件->来源于react-redux的connect的加工->返回的处理state,使用redux的代码

/*
const handleToggle = ID => {
    // props.dispatch(toggletodo(ID))
    toggle(ID)
  }

  const handleDele = ID => {
    // props.dispatch(deletetodo(ID))
    dele(ID)
  }

*/
