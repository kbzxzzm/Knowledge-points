import React, { createRef } from 'react'

// 在add 组件  点击添加 给全局数据 list 加一条数据
import { connect }  from 'react-redux'
let Add=(props) => {

  return (
    <>
      <input type='text' id="text" />
      <button
      onClick={()=>{
        // 获取文本框的值  我简单点之间通过id获取 就不写 value和onchange了 
        let value=document.getElementById("text").value
        console.log('文本框的值',value)
        //  点击 添加 执行 mapDispatch的 函数 在函数里面dispatch触发action
        props.addTodo(value)
      }}
      >
        添加
      </button>
    </>
  )
}

// 写上 mapStateToProps 专门用来 获取全局数据的
// mapDispatchToProps 专门用来写函数 操作全局数据的
// 不用就留空就行
// let mapStateToProps=(state,ownProps)=>{
//   // state 全局数据对象
//   return {
//     // props上的名字:全局数据
//   }
// }

let mapDispatchToProps=(dispatch,ownProps)=>{
   return {
      // 函数名:函数
      addTodo:(value)=>{
         console.log('点击执行的mapdispatch--addTodo')
        //  dispatch action ---》执行reducer--》在reducer里面添加全局数据
        let addAction={
          type:"add",
          value:value
        }
        dispatch(addAction)
      }
   }
}
// export default Add
export default connect(null,mapDispatchToProps)(Add)
// 他的其他改变 写法
// 1 两个都用
// export default connect(mapStateToProps,mapDispatchToProps)(Add)
// 2 只用mapStateToProps
// export default connect(mapStateToProps)(Add)
// 3 只用mapDispatchToProps
// export default connect(null,mapDispatchToProps)(Add)
// 4 都不用  很少见 因为没有意义 不用 就连connect都不需要了
// export default connect()(Add)