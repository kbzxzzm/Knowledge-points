// store的配置文件

import { createStore } from 'redux'

import reducer from '../reducer'

// state的初始值
const state = [
  { id: 1, text: 'sleep', done: false },
  { id: 2, text: 'eat', done: true }
]

const configStore = () => {
  const store = createStore(reducer, state)
  store.subscribe(() => console.log(store.getState()))
  return store
}

export { configStore }
