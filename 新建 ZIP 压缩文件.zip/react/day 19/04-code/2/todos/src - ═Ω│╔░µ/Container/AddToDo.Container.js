import { connect } from 'react-redux'
import { addtodo } from '../actions'
import AddToDo from '../components/AddToDo.js'

const mapDispatchToProps = dispatch => {
  return {
    add: text => {
      dispatch(addtodo(text))
    }
  }
}

export default connect(
  null,
  mapDispatchToProps
)(AddToDo)

// const mapStateToProps = state => {
//   return {}
// }
