// 对应的是ToDoList.js中的容器组件代码
import { connect } from 'react-redux'
import { toggletodo, deletetodo } from '../actions'
import ToDoList from '../components/ToDoList'

const mapStateToProps = state => {
  return {
    list: state
  }
}

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    toggle: ID => dispatch(toggletodo(ID)),
    dele: ID => dispatch(deletetodo(ID))
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ToDoList)
