// 根组件
import React from 'react'

// 使用展示组件
// import AddToDo from './components/AddToDo'
// import ToDoList from './components/ToDoList'

// 使用容器组件
import AddToDo from './Container/AddToDo.Container.js'
import ToDoList from './Container/ToDoList.Container.js'

export default () => (
  <div>
    {/* 添加任务 */}
    <AddToDo />
    {/* 任务列表 */}
    <ToDoList />
  </div>
)

// 函数组件->无状态
// 类组件->有状态

// App.js->无状态的函数组件

// input输入框的表单处理需要this.state this.setState()-> 函数组件无状态
// ->使用`受控的方式`无法处理input标签
// -> 可以使用非受控组件的方法->ref操作dom的方法
// 1. 获取React.createRef方法,创建标识
// 2. 为要操作的元素设置ref属性,属性的值是第一步的返回值
// 3. 获取要操作的DOM元素-> 标识.current
