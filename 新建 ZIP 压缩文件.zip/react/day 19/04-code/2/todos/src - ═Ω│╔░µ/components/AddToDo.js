import React, { createRef } from 'react'

export default props => {
  const { add } = props
  const textRef = createRef()
  const handleAdd = () => {
    if (textRef.current.value.trim().length === 0) return
    add(textRef.current.value)
    // 添加后的清空-> 通过ref操作dom的方式清空->dom元素->textRef.current.value=''
    textRef.current.value = ''
  }
  return (
    <>
      <input ref={textRef} />
      <button
        onClick={() => {
          handleAdd()
        }}
      >
        ADD
      </button>
    </>
  )
}
