// action的type管理的模块->actionType/index.js

// 添加 ADD_TODO
// 删除 DELETE_TODO
// 切换 TOGGLE_TODO

const ADD_TODO = 'ADD_TODO'
const DELETE_TODO = 'DELETE_TODO'
const TOGGLE_TODO = 'TOGGLE_TODO'

export { ADD_TODO, DELETE_TODO, TOGGLE_TODO }
