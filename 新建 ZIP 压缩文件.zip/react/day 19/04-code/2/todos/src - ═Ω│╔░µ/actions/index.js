// action模块
// 1. {type:?}
// 2. actionCreater->创建action的函数

import * as ActionType from '../actionType'

// 添加 addtodo
// 删除 deletetodo
// 切换 toggletodo

// 一个任务的数据结构->
// {id:1,text:'吃饭',done:false}
// {id:2,text:'睡觉',done:false}
// {id:3,text:'玩',done:false}

// 箭头函数函数体是一行 自动return
const addtodo = text => ({ type: ActionType.ADD_TODO, text })

const deletetodo = id => ({ type: ActionType.DELETE_TODO, id })

const toggletodo = id => ({ type: ActionType.TOGGLE_TODO, id })

export { addtodo, deletetodo, toggletodo }
