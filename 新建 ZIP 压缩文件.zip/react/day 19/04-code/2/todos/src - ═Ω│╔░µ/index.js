import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import { Provider } from 'react-redux'
import { configStore } from './configStore'
import * as serviceWorker from './serviceWorker'
import './index.css'
const store = configStore()

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
)

serviceWorker.unregister()

/*
// index.js->单独测试redux的文件

import { createStore } from 'redux'
import { addtodo, deletetodo, toggletodo } from './actions'
import reducer from './reducer'

// 测试reducer
const store = createStore(reducer)
store.subscribe(() => console.log(store.getState()))

// 测试action
store.dispatch(addtodo('玩1'))
// store.dispatch(addtodo('玩2'))
// store.dispatch(addtodo('玩3'))
// store.dispatch(deletetodo(12))
// store.dispatch(toggletodo(11))


*/
