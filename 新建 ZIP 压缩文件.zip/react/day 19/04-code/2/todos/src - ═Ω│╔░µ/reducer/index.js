// 1. 一个reducer就是一个纯函数
// 2. reducer函数->(旧state,action)=>return 新state
// 3. 一个项目的reducer函数只有一个

import * as ActionType from '../actionType'
// 思考: state的默认值应该是什么?->
// [{id:1,text:'sleep',done:false},{id:3,text:'sleep2',done:false},..]

export default (state = [], action) => {
  switch (action.type) {
    case ActionType.ADD_TODO:
      let state1 = [...state]
      if (state.length === 0) {
        return [{ id: 1, text: action.text, done: false }]
      }
      state1.push({
        id: state1[state1.length - 1].id + 1,
        text: action.text,
        done: false
      })

      return state1
    case ActionType.DELETE_TODO:
      // 分析:这里要做的事儿->filter()
      // 1. 遍历state
      // 2. 筛选符合条件的元素
      // 3. 返回新数组
      return state.filter(item => action.id !== item.id)

    case ActionType.TOGGLE_TODO:
      // 已有数据:action.id=>11
      // 1. 遍历原始数组
      // 2. 返回新数组
      // 3. 条件+执行语句
      let temp = [...state]
      return temp.map(item => {
        if (action.id === item.id) item.done = !item.done
        return item
      })

    default:
      return state
  }
}
