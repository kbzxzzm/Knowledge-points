import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import './index.css'
import { Provider } from 'react-redux'

// 导入 store
import { store } from './store'

ReactDOM.render(
    <Provider store={store}>
       <App />
    </Provider>
    ,
  document.getElementById('root')
)

// 对全局数据 list  的增删改查
// 要求 有一个全局数据 list 代表今天要完成的所有事
// 1. 列表展示  list组件循环全局数据list  显示所有要做的事 
// 2. 添加任务  在add组件 点击add添加  给全局数据list 再加一个事
// 3. 删除任务 点击X 删除全局数据list  对应的那个数据

// isfinish:false false 就是 还没有做  true 做了
// let list=[
//   {id:1,name:"打篮球",isfinish:false},
//   {id:2,name:"打足球",isfinish:false},
//   {id:3,name:"打男朋友",isfinish:false}
// ]

















/*
// index.js->单独测试redux的文件

import { createStore } from 'redux'
import { addtodo, deletetodo, toggletodo } from './actions'
import reducer from './reducer'

// 测试reducer
const store = createStore(reducer)
store.subscribe(() => console.log(store.getState()))

// 测试action
store.dispatch(addtodo('玩1'))
// store.dispatch(addtodo('玩2'))
// store.dispatch(addtodo('玩3'))
// store.dispatch(deletetodo(12))
// store.dispatch(toggletodo(11))


*/
