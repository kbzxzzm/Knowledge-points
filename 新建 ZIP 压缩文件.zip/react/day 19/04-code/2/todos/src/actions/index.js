// let addAction={
//   type:"add",
//   value:'添加的啊啊'
// }
import { ADD_TYPE }  from '../actionTypes'
// 后面 别人的代码 经常这样写
let addAction=(value)=>{
    console.log('valueaaa',value)
   return {
      type:ADD_TYPE,
      value:value
  }

}

export { addAction  }