
// 1 下载 react-redux redux 包
// 2 导入  Provider createStore
// 3 使用createStore创建一个全局数据store
// 4 使用Provider 包裹住根组件
import { createStore } from 'redux'
// 大家会见到 别人 写了好多文件夹  其实就是我们学的 但是他们会写很多文件夹
import { reducer } from '../reducer'
// 全局数据对象
import { initstate }  from '../state'
// reducer函数 
// let store=createStore(reducer函数,全局数据对象)
let store=createStore(reducer,initstate)

export { store }