// reducer函数 什么都不干的情况下 需要原样 return state 
let reducer=(state,action)=>{
  // state 全局数据  action dispatch触发过来的action
  // 一般在reducer 接受action 判断type做 不同的操作 建议写switch case
  // react操作 数据最好 新创建一个操作 再赋值
  console.log('reducer接受的action',action)
  switch (action.type) {
    case 'del': //删除
      console.log('删除操作')
      let state11={...state}
      let newlist=[...state11.list]
      // 找到索引  删除对应的 项
      // findIndex 找到 满足条件的那项的索引
      let index=newlist.findIndex(item=>{
           return item.id===action.id
      })
      newlist.splice(index,1) ;//从索引开始 删除一个
      state11.list=newlist
      console.log('index',index)
      return state11
    case 'add':
      //  添加操作
      let state22={...state}
      let addlist=[...state22.list]
      // {id:3,name:"打代码",isfinish:false}
      addlist.push({
         id:addlist[addlist.length-1].id+1,
         name:action.value,
         isfinish:false
      })
      state22.list=addlist;//赋新值
      return state22
    //  case  
    default:// 默认
      return state
  }
 
}

export { reducer }