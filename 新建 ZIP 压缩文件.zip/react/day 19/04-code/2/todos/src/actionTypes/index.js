// 这、个文件 只写 对应的 type名字
let ADD_TYPE='add'

export { ADD_TYPE }