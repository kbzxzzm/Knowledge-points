let initstate={
  list:[
      {id:1,name:"打篮球吗？",isfinish:false},
      {id:2,name:"打足球",isfinish:false},
      {id:3,name:"打男朋友",isfinish:false}
  ]
}

export { initstate }