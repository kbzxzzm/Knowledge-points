// 组件 1 先导入react
import React from 'react'
// 2 创建组件并导出
// App 根组件 在react中 经常用来配置基本路由
import {BrowserRouter as Router,Route,Link} from 'react-router-dom'
// 导入home组件
import Home from './page/Home'

export default  class App extends React.Component{
  // 必须写render
  render(){
     //  必须return html代码
    //  一定要在整个项目的 最外层 包裹一次 BrowserRouter
     return <Router>
          <div>
  
              {/* 下面挖坑显示  要求 先到home 再显示user */}
              <Route path="/home" component={Home}></Route>
              
                   
          </div>

     </Router>
     
  }
}
