// 组件 1 先导入react
import React from 'react'
// 2 创建组件并导出
export default  class User extends React.Component{
  // 必须写render
  render(){
     //  必须return html代码
     return <div>
             我是User
       </div>
  }
}
