// 组件 1 先导入react
import React from 'react'
import { Route } from 'react-router-dom'

import User from './User'
import Index from './Index'
import { Layout, Menu, Breadcrumb, Icon } from 'antd';

const { SubMenu } = Menu;  // 如果这里没写 那么 也需要 Menu.SubMenu
const { Header, Content, Sider } = Layout;

// 2 创建组件并导出
export default class Home extends React.Component {
  // 必须写render
  render() {
    //  必须return html代码
    return <div>

      {/* <h1>我是home</h1> */}
      {/* 在home 显示user */}
      {/* <Route path="/home/user" component={User}></Route> */}
      {/* Layout div外层盒子 里面可以嵌套Layout Sider  Header Content Footer  */}
      {/* Menu.Item 具体的能点击的项 */}
      {/* SubMenu 是二级菜单 能伸缩 */}
      <Layout>
        {/* 头 */}
        <Header className="header">
          <div className="logo" />
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={['1']} //选中的那项
            style={{ lineHeight: '64px' }}
          >
            <Menu.Item key="1">首页</Menu.Item>
            <Menu.Item key="2">用户中心</Menu.Item>
            <Menu.Item key="3">退出</Menu.Item>
          </Menu>
        </Header>
        <Layout>
          {/* 左侧 侧边栏 */}
          <Sider width={200} style={{ background: '#fff' }}>
            <Menu
              mode="inline"
              defaultSelectedKeys={['1']} // 默认选中谁
              defaultOpenKeys={['sub1']} // 默认展开谁
              style={{ height: '100%', borderRight: 0 }}
              onClick={(obj)=>{
                // key 正好 写上我们对于的路径 非常方便了
                 // 点击 菜单某一项 执行 { item, key, keyPath, domEvent }
                  console.log('obj,',obj)
                  // 点击 跳转对应的地址就行
                  this.props.history.push(obj.key)
              }}
            >
              <SubMenu
                key="sub1"
                title={
                      <span>
                        <Icon type="user" />
                        首页
                  </span>
                }
              >
                <Menu.Item key="/home/index">首页页面</Menu.Item>
                <Menu.Item key="/home/role">权限</Menu.Item>
              </SubMenu>
              <SubMenu
                key="sub2"
                title={
                  <span>
                    <Icon type="laptop" />
                    用户管理
              </span>
                }
              >
                <Menu.Item key="/home/user">用户列表</Menu.Item>
                <Menu.Item key="/home/adduser">添加用户</Menu.Item>
                <Menu.Item key="7">用户权限</Menu.Item>
              </SubMenu>
              <SubMenu
                key="sub3"
                title={
                  <span>
                    <Icon type="notification" />
                    商品管理
              </span>
                }
              >
                <Menu.Item key="9">商品列表</Menu.Item>
                <Menu.Item key="10">添加商品</Menu.Item>
                <Menu.Item key="11">商品图片</Menu.Item>
              </SubMenu>
            </Menu>
          </Sider>
          <Layout style={{ padding: '0 24px 24px' }}>
            {/* 面包屑 */}
            <Breadcrumb style={{ margin: '16px 0' }}>
              <Breadcrumb.Item>Home</Breadcrumb.Item>
              <Breadcrumb.Item>List</Breadcrumb.Item>
              <Breadcrumb.Item>App</Breadcrumb.Item>
            </Breadcrumb>
            {/* 内容部分  */}
            <Content
              style={{
                background: '#fff',
                padding: 24,
                margin: 0,
                minHeight: 280,
              }}
            >

              {/*内容部分 配置子路由 */}
              <Route path="/home/user" component={User}></Route>
              <Route path="/home/index" component={Index}></Route>
              {/* 在这里 匹配很多子路由切换就行了 */}


        </Content>
          </Layout>
        </Layout>
      </Layout>
    </div>
  }
}
