// 组件 1 先导入react
import React from 'react'
// 2 创建组件并导出
export default  class Hello extends React.Component{
  // 必须写render
  render(){
     //  必须return html代码
     return <div>
           <ul>
             <li>111112223433</li>
             <li>22222</li>
           </ul>
       </div>
  }
}
// 导出
// export default Hello