// 入口
// 1 引入 react react-dom包
import React from 'react'
import ReactDOM from 'react-dom'
// 2 创建react元素--jsx语法：1 可以在js里面写html 2 在html范围 要写js必须 { 写js }
// babel给我们转换了 所以才能写

// 导入
import App from './App'

// 3 渲染到页面  ReactDOM.render(创建组件元素,页面上的dom元素)
ReactDOM.render(<App></App>,document.getElementById("root"))
