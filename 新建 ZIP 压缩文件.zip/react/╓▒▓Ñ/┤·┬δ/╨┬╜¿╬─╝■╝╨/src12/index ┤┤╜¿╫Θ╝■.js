// 入口
// 1 引入 react react-dom包
import React from 'react'
import ReactDOM from 'react-dom'
// 2 创建react元素--jsx语法：1 可以在js里面写html 2 在html范围 要写js必须 { 写js }
// babel给我们转换了 所以才能写
// let a='我是a'

// let myul=<ul>
//   <li>1111</li>
//   <li>2222--{a}</li>
// </ul> 
// 组件的创建 1 函数组件function
// function Hello(){
//     // return html
//     return <div>
//          <ul>
//            <li>11111</li>
//            <li>22222</li>
//          </ul>
//     </div>
// }
// 组件的创建 2 class 类组件
class Hello extends React.Component{
   // 必须写render
   render(){
      //  必须return html代码
      return <div>
            <ul>
              <li>111112223433</li>
              <li>22222</li>
            </ul>
        </div>
   }
}

// 3 渲染到页面  ReactDOM.render(创建组件元素,页面上的dom元素)
ReactDOM.render(<Hello></Hello>,document.getElementById("root"))
