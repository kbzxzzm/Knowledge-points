// 组件 1 先导入react
import React from 'react'
import { Route } from 'react-router-dom'

import User from './User'
// 2 创建组件并导出
export default  class Home extends React.Component{
  // 必须写render
  render(){
     //  必须return html代码
     return <div> 
              
             <h1>我是home</h1>
             {/* 在home 显示user */}
             <Route path="/home/user" component={User}></Route>
            
       </div>
  }
}
