// 组件 1 先导入react
import React from 'react'
// 2 创建组件并导出
// App 根组件 在react中 经常用来配置基本路由
import {BrowserRouter as Router,Route,Link} from 'react-router-dom'
// 导入home组件
import Home from './page/Home'

export default  class App extends React.Component{
  // 必须写render
  render(){
     //  必须return html代码
    //  一定要在整个项目的 最外层 包裹一次 BrowserRouter
     return <Router>
          <div>
              我是app
              {/* <ul>
                <li>
                  <Link to="/home">去home页面</Link>
                </li>
                <li>
                  <Link to="/user">去user页面</Link>
                </li>
              </ul> */}

              <hr/>
              {/* 显示对应的组件  /home 想匹配显示 Home组件 */}
              {/* <Route path="地址" component={显示的组件}></Route> 
                  Route  1 匹配地址路径  2 挖坑 写在哪就把组件显示在哪
              */}
              {/* 父子嵌套路由  在home里面 显示user  路径必须以父路由开头
                 1 在父路由里面 写 Route子路由
                 2 子路由路径 必须 以父路由开头
                 3 父路由 不要加 exact
              */}
              {/* 兄弟 建议加上  exact 精确匹配 必须路径一模一样  不加 exact 模糊匹配 只要 /路径开头匹配了 就会显示 */}
              <Route exact  path="/home" component={Home}></Route>
              <Route exact path="/home/abc" component={Home}></Route>
              
             
          </div>

     </Router>
     
  }
}
